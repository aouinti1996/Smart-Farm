#include <gtk/gtk.h>

  GtkWidget *acceuil;
  GtkWidget *gestion;
GtkWidget *window1;
GtkWidget *window2;
GtkWidget *window3;
GtkWidget *window4;
typedef struct{
int j;
int m;
int a;

}date;



typedef struct{
char nom[20];
char marque[20];
char reference[20];
char type[20];
date ddf;
char etat[20];
}equipement;







void ajouter_equipement(equipement e );

int exist_equipement(char*reference);
void supprimer_equipement(char*reference);
void modifier_equipement(equipement e);

