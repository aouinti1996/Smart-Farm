#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include "callbacks.h"
#include<string.h>
#include "equipement.h"


//Ajouter un equipement 

void ajouter_equipement( equipement e){
FILE*f=NULL; //flot de donnée
f=fopen("equipement.txt","a+");
fprintf(f,"%s %s %s %s %d %d %d %s \n",e.nom,e.marque,e.reference,e.type,e.ddf.j,e.ddf.m,e.ddf.a,e.etat);;  
fclose(f); 
}
//********************************************************





//verifier l'existance 

int exist_equipement(char*reference){
FILE*f=NULL;
 equipement e;
f=fopen("equipement.txt","r");// ouverture du fichier equipement en  mode lecture 
while(fscanf(f,"%s %s %s %s %d %d %d %s\n",e.nom,e.marque,e.reference,e.type,&e.ddf.j,&e.ddf.m,&e.ddf.a,e.etat)!=EOF){
if(strcmp(e.reference,reference)==0)
return 1;   //id existe deja 
}
fclose(f);
return 0;
}

//*****************************************************************




//supprimer equi 
void supprimer_equipement(char*reference){
FILE*f=NULL;
FILE*f1=NULL;
equipement e ;
f=fopen("equipement.txt","r");
f1=fopen("ancien.txt","w+");//mode lecture et ecriture 
while(fscanf(f,"%s %s %s %s %d %d %d %s\n",e.nom,e.marque,e.reference,e.type,&e.ddf.j,&e.ddf.m,&e.ddf.a,e.etat)!=EOF){
if(strcmp(reference,e.reference)!=0)fprintf(f1,"%s %s %s %s %d %d %d %s \n",e.nom,e.marque,e.reference,e.type,e.ddf.j,e.ddf.m,e.ddf.a,e.etat);
}
fclose(f);
fclose(f1);
remove("equipement.txt");
rename("ancien.txt","equipement.txt");
}

//******************************************************************



void modifier_equipement(equipement e){
FILE*f=NULL;
FILE*f1=NULL;
equipement eq ;
f=fopen("equipement.txt","r");
f1=fopen("ancien.txt","w+");
while(fscanf(f,"%s %s %s %s %d %d %d %s\n",eq.nom,eq.marque,eq.reference,eq.type,&eq.ddf.j,&eq.ddf.m,&eq.ddf.a,eq.etat)!=EOF){
if( strcmp(e.reference,eq.reference)==0)
{
fprintf(f1,"%s %s %s %s %d %d %d %s \n",e.nom,e.marque,e.reference,e.type,e.ddf.j,e.ddf.m,e.ddf.a,e.etat);
}
else
{
fprintf(f1,"%s %s %s %s %d %d %d %s \n",eq.nom,eq.marque,eq.reference,eq.type,eq.ddf.j,eq.ddf.m,eq.ddf.a,eq.etat);
}

}
fclose(f);
fclose(f1);
remove("equipement.txt");
rename("ancien.txt","equipement.txt");
}














