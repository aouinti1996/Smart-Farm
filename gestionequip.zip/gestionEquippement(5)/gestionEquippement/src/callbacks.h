#include <gtk/gtk.h>


void
on_AcceuilGestion_clicked              (GtkButton       *button,
                                        gpointer         user_data);


void
on_GestionAcceuil_clicked              (GtkButton       *button,
                                        gpointer         user_data);


void
on_bmodifier_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_bsupprimer_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_bafficher12_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_Ajouterequipement_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_Modifierequipement_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_chercherequipement_clicked          (GtkButton       *button,
                                        gpointer         user_data);



void
on_modifier_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton3occmodif_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);



void
on_checkbutton2confmodif_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonoccajout_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2neufajou_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


void
on_checkbutton1ajou_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton1ajout_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton3occmodifier_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_eqAfficher_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_ouisupp_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_nonsup_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifretour_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeretourr_clicked                 (GtkButton       *button,
                                        gpointer         user_data);
void
on_treeajou_clicked                    (GtkButton       *button,
                                        gpointer         user_data);
void
on_modifaffich_clicked                 (GtkButton       *button,
                                        gpointer         user_data);
void
on_buttonradioajou_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
void
on_radiobutton2affich_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
void
on_button11_clicked                    (GtkButton       *button,
                                        gpointer         user_data);







