#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif


#include <gtk/gtk.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include"tree.h"
#include"equipement.h"

GtkTreeSelection *selection1;
int btnradiomodif=0;
int btnradioajou=0;
int validajou=0;
int validmodif=0;
int btnradiointerface=0;
void
on_AcceuilGestion_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

/*preparation du treeView*/
GtkWidget *p;
gtk_widget_hide (acceuil);
gestion = create_gestion ();

//gtk_widget_show (gestion);
window1=create_window1();
//gtk_widget_show (window1);
p=lookup_widget(window1,"treeview2");
Afficherequipement(p);

window2=create_window2();
 //gtk_widget_show (window2);
window3=create_window3();
// gtk_widget_show (window3);
window4=create_window4();
 gtk_widget_show (window4);
gtk_combo_box_set_active (GTK_COMBO_BOX(lookup_widget(gestion,"combobox1balkis")),0 );
gtk_combo_box_set_active (GTK_COMBO_BOX(lookup_widget(window2,"combobox2balkis")),0 );
}



void
on_Ajouterequipement_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{equipement e;

GtkWidget *entryNom, *entryMarque, *entryReference, *entryType, *entryj, *entrym, *entrya, *entryetat;
GtkWidget *labelnom;
GtkWidget *labelmarque;
GtkWidget *labelreference;
GtkWidget *labeltype;
GtkWidget *labelvalid;

GtkWidget *existe;
GtkWidget* success;
int b=1;

entryNom=lookup_widget(gestion,"entryNombalkis");
entryMarque=lookup_widget(gestion,"entryMarquebalkis");
entryReference=lookup_widget(gestion,"entryReferencebalkis");
entryType=lookup_widget(gestion,"combobox1balkis");
entryj=lookup_widget(gestion,"spinbutton1balkis");
entrym=lookup_widget(gestion,"spinbutton2balkis");
entrya=lookup_widget(gestion,"spinbutton3balkis");


labelnom=lookup_widget(gestion,"label13balkis");
labelmarque=lookup_widget(gestion,"label7balkis");
labelreference=lookup_widget(gestion,"label8balkis");
labeltype=lookup_widget(gestion,"label9balkis");
labelvalid=lookup_widget(gestion,"label91balkis");
existe=lookup_widget(gestion,"label34balkis");
success=lookup_widget(gestion,"label35balkis");

strcpy(e.nom,gtk_entry_get_text(GTK_ENTRY(entryNom)));
strcpy(e.marque,gtk_entry_get_text(GTK_ENTRY(entryMarque) ) );
strcpy(e.reference,gtk_entry_get_text(GTK_ENTRY(entryReference) ) );
strcpy(e.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(entryType) ) );
e.ddf.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entryj));

e.ddf.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entrym));

e.ddf.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entrya));

if (btnradioajou==2){
strcpy(e.etat,"neuf");}
else if (btnradioajou==1){
strcpy(e.etat,"occasion");}
gtk_widget_hide(success);

if(strcmp(e.nom,"")==0){
		  gtk_widget_show (labelnom);
b=0;
}
else {
		  gtk_widget_hide(labelnom);
}

if(strcmp(e.marque,"")==0){
		  gtk_widget_show (labelmarque);
b=0;
}
else {
		  gtk_widget_hide(labelmarque);
}
if(strcmp(e.reference,"")==0){
		  gtk_widget_show (labelreference);
b=0;
}
else {
		  gtk_widget_hide(labelreference);
}
if(strcmp(e.type,"....")==0){
		  gtk_widget_show (labeltype);
b=0;
}
else {
		  gtk_widget_hide(labeltype);
}
gtk_widget_show(labelvalid);
if (validajou==1)
{gtk_widget_hide(labelvalid);
if(b==1)
{

        if(exist_equipement(e.reference)==1)
        {

				  gtk_widget_show (existe);
        }
        else {
						  gtk_widget_hide (existe);
                ajouter_equipement(e);

						  gtk_widget_show (success);

        }

         //  ajouter_equipement(e);

						
        }}}
//mise a jour du treeView
        //GtkWidget* p=lookup_widget(window1,"treeview2");

        //Afficherequipement(p);







void
on_Modifierequipement_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{ equipement e ;
       	 GtkWidget *entryNom, *entryMarque, *entryReference, *entryType, *entryj, *entrym, *entrya, *entryetat,*labelvalid,*success;

entryNom=lookup_widget(window2,"modifNombalkis");
entryMarque=lookup_widget(window2,"modifMarquebalkis");
entryReference=lookup_widget(window2,"label20balkis");
entryType=lookup_widget(window2,"combobox2balkis");
entryj=lookup_widget(window2,"spinbutton4balkis");
entrym=lookup_widget(window2,"spinbutton5balkis");
entrya=lookup_widget(window2,"spinbutton6balkis");
labelvalid=lookup_widget(window2,"label92balkis");
success=lookup_widget(window2,"label37balkis");
 strcpy(e.nom,gtk_entry_get_text(GTK_ENTRY(entryNom) ) );
 strcpy(e.marque,gtk_entry_get_text(GTK_ENTRY(entryMarque) ) );
 strcpy(e.reference,gtk_label_get_text(GTK_LABEL(entryReference) ) );
 strcpy(e.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(entryType) ) );
e.ddf.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entryj));
e.ddf.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entrym));
e.ddf.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entrya));
if (btnradiomodif==2){
strcpy(e.etat,"neuf");}
else if (btnradiomodif==1){
strcpy(e.etat,"occasion");}
gtk_widget_show(labelvalid);
gtk_widget_hide(success);
if (validmodif==1)
{
     

gtk_widget_hide(labelvalid);
gtk_widget_show(success);

        modifier_equipement(e);
}
//Afficherequipement(lookup_widget(window1,"treeview2"));
//mise ajour du tree view 
       //Afficherequipement(lookup_widget(window1,"treeview1"));
	//gtk_widget_show(lookup_widget(window2,"label37"));
        //GtkWidget *p=lookup_widget(window1,"treeview2");
        //Afficherequipement(p);


}




void
on_chercherequipement_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *p1;
GtkWidget *entry;
GtkWidget *labelnom;
GtkWidget *nbResultat;
GtkWidget *message;
char reference[30];
char chnb[30];
int b=0,nb; //b=0  entry  cherche vide 
entry=lookup_widget(window1,"entry10balkis");
labelnom=lookup_widget(window1,"label28balkis");
p1=lookup_widget(window1,"treeview2");
strcpy(reference,gtk_entry_get_text(GTK_ENTRY(entry)));

if(strcmp(reference,"")==0){
  gtk_widget_show (labelnom);b=0;
}else{
b=1;
gtk_widget_hide (labelnom);}

if(b==0)
    {return;
    }
    else
    {

nb=Chercherequipement(p1,"equipement.txt",reference);
// afficher le nombre de resultats obtenue par la recherche */

sprintf(chnb,"%d",nb);        //conversion int==> chaine car la fonction gtk_label_set_text naccepte que chaine
nbResultat=lookup_widget(window1,"label27balkis");
message=lookup_widget(window1,"label26balkis");
gtk_label_set_text(GTK_LABEL(nbResultat),chnb);

gtk_widget_show (nbResultat);
gtk_widget_show (message);



}

}


void
on_GestionAcceuil_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_show (window4);
gtk_widget_hide (gestion);

}




void
on_bmodifier_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
        
}


void
on_bsupprimer_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
    gchar *nom;
    gchar *marque;
    gchar *reference;
    gchar *type;
    gint *j;
    gint *m;
gint *a;
gchar *etat;
    GtkTreeModel     *model;
    GtkTreeIter iter;
       if (gtk_tree_selection_get_selected(selection1, &model, &iter))
        {
            gtk_tree_model_get (model,&iter,0,&nom, 1, &marque, 2, &reference,3,&type,4,&j,5,&m,6,&a,7,&etat,-1);//recuperer les information de la ligne selectionneé
            supprimer_equipement(reference);
            Afficherequipement(lookup_widget(window1,"treeview2"));        
        }
}


void
on_bafficher12_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
Afficherequipement(lookup_widget(window1,"treeview2"));   
}


void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)//signale du treeView (Double click)
{
     gchar *nom;
    gchar *marque;
    gchar *reference;
    gchar *type;
    gint *j;
    gint *m;
gint *a;
gchar *etat;
      
        GtkTreeModel     *model;
        GtkTreeIter iter;
        GtkWidget *p=lookup_widget(window1,"treeview2");
        selection1 = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
       


}



void
on_modifier_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
 char *nom;
    char *marque;
    char *reference;
   char *type;
    int j;
    int m;
int a;
char *etat;

        GtkTreeModel     *model;
GtkWidget     *labelvalid;

        GtkTreeIter iter;
        if (gtk_tree_selection_get_selected(selection1, &model, &iter))
        {

        gtk_widget_hide(lookup_widget(window2,"label37balkis"));//cacher label modifier avec succees
gtk_widget_hide(lookup_widget(window2,"label92balkis"));
                gtk_tree_model_get (model,&iter,0,&nom, 1, &marque, 2, &reference,3,&type,4,&j,5,&m,6,&a,7,&etat,-1);

    gtk_entry_set_text(GTK_ENTRY(lookup_widget(window2,"modifNombalkis")),nom);
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(window2,"modifMarquebalkis")),marque);
             gtk_label_set_text(GTK_ENTRY(lookup_widget(window2,"label20balkis")),reference);
 //gtk_entry_set_text(GTK_ENTRY(lookup_widget(window2,"modifReference")),reference);
if (strcmp(type,"Machine")==0){
gtk_combo_box_set_active (GTK_COMBO_BOX(lookup_widget(window2,"combobox2balkis")),2 );
}
else if (strcmp(type,"Matriel")==0){
gtk_combo_box_set_active (GTK_COMBO_BOX(lookup_widget(window2,"combobox2balkis")),1 );}
		//
gtk_spin_button_set_value(GTK_SPIN_BUTTON(lookup_widget(window2,"spinbutton4balkis")),j);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(lookup_widget(window2,"spinbutton5balkis")),m);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(lookup_widget(window2,"spinbutton6balkis")),a);

if (strcmp(etat,"occasion")==0){
gtk_toggle_button_set_active(GTK_RADIO_BUTTON (lookup_widget(window2,"radiobutton3occmodif")),TRUE);
}
else if (strcmp(etat,"neuf")==0){
gtk_toggle_button_set_active(GTK_RADIO_BUTTON (lookup_widget(window2,"radiobutton3occmodifier")),TRUE);
}
gtk_widget_show (window2);
gtk_widget_hide (window1);

//gtk_combo_box_set_active(GTK_COMBO_BOX(lookup_widget(window2,"combobox2")), );
//radiobutton3occmodif
         // combobox2
//spinbutton4
//spinbutton5
//spinbutton6


                //GtkWidget* msgId=lookup_widget(window2,"label20");
                //GtkWidget* msg1=lookup_widget(window2,"label36");
                
                //gtk_widget_show(msgId);
                //gtk_widget_show(msg1);
                //gtk_widget_show(lookup_widget(window2,"button4"));//afficher le bouton modifier
                //gtk_notebook_prev_page(GTK_NOTEBOOK(lookup_widget(gestion,"notebook1")));//redirection vers la page precedente
       
        }

}


void
on_radiobutton3occmodif_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{btnradiomodif=1;}
}




void
on_checkbutton2confmodif_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_CHECK_BUTTON (togglebutton)))
{validmodif=1;}
else
{validmodif=0;}
}


void
on_radiobuttonoccajout_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{btnradioajou=1;}
}


void
on_radiobutton2neufajou_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{btnradioajou=2;}
}




void
on_checkbutton1ajout_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_CHECK_BUTTON (togglebutton)))
{validajou=1;}
else
{validajou=0;}
}


void
on_radiobutton3occmodifier_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{btnradiomodif=2;}
}


void
on_eqAfficher_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_show (window1);
gtk_widget_hide (gestion);
Afficherequipement(lookup_widget(window1,"treeview2"));   
}


void
on_ouisupp_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_nonsup_clicked                      (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_modifretour_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_show (window1);
gtk_widget_hide (window2);

}


void
on_treeretourr_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_show (window4);
gtk_widget_hide (window1);
}


void
on_modifaffich_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_show (window1);
gtk_widget_hide (window2);
Afficherequipement(lookup_widget(window1,"treeview2"));
}


void
on_buttonradioajou_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{btnradiointerface=1;}

}


void
on_radiobutton2affich_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{btnradiointerface=2;}
}


void
on_button11_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
if (btnradiointerface==2)
{gtk_widget_show (window1);
gtk_widget_hide (window4);}
else
if (btnradiointerface==1)
{gtk_widget_show (gestion);
gtk_widget_hide (window4);

}
}


void
on_treeajou_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_show (gestion);
gtk_widget_hide (window1);
}

