#include <gtk/gtk.h>
  GtkWidget *acceuil;
  GtkWidget *gestion;
GtkWidget *window1;
GtkWidget *window2;
GtkWidget *window3;
GtkWidget *window4;
typedef struct{
int j;
int m;
int a;

}date;



typedef struct{
char nom[20];
char marque[20];
char reference[20];
char type[20];
date ddf;
char etat[20];
}equipement;


void
on_AcceuilGestion_clicked              (GtkButton       *button,
                                        gpointer         user_data);


void
on_GestionAcceuil_clicked              (GtkButton       *button,
                                        gpointer         user_data);


void
on_bmodifier_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_bsupprimer_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_bafficher12_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_Ajouterequipement_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_Modifierequipement_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_chercherequipement_clicked          (GtkButton       *button,
                                        gpointer         user_data);



void
on_modifier_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton3occmodif_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);



void
on_checkbutton2confmodif_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonoccajout_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2neufajou_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


void
on_checkbutton1ajou_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton1ajout_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton3occmodifier_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_eqAfficher_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_ouisupp_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_nonsup_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifretour_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeretourr_clicked                 (GtkButton       *button,
                                        gpointer         user_data);
void
on_treeajou_clicked                    (GtkButton       *button,
                                        gpointer         user_data);
void
on_modifaffich_clicked                 (GtkButton       *button,
                                        gpointer         user_data);
void
on_buttonradioajou_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
void
on_radiobutton2affich_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
void
on_button11_clicked                    (GtkButton       *button,
                                        gpointer         user_data);








void
on_treeview2TR_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_TRtreeretourr_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_TRtreeajou_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_TRbutton6_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_TRbmodifier_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_calculenor_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_TRbsupprimer_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_TRbafficher12_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_TRbutton19_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_TRRetourAffich_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_TRQuitAjouter_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_TRAjouterTroupeaux_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_TRtrouAfficher_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_Bonsant___toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_TRcheckbutton1ajout_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Malade_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_MaladeModif_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Bonsant__Modif_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_TRbutton24_retourM_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_TRbutton22_quit_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_TRModifiertrou_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_TRModifAffich_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_GestionTroupeaux_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_TRcheckbutton2_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_TRRetourAffiche_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_gestionouvries_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_ajouter_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview_row_activated              (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_supprimer1_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifier2_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_chercher_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobuttonnon_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonoui_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonvalider_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ajoute_cap_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_annul_ajt_cap_clicked        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button12_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_annul_modif_cap_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_modif_cap_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button13_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_rech_mod_cap_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button50_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button52_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_affich_cap_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_sup_cap_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_rech_sup_cap_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button56_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_gestioncapteur_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_gestionstock_clicked                (GtkButton       *button,
                                        gpointer         user_data);
void on_button51_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_ajouterpmalek_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_chercherpmalek_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_supprimerpmalek_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_ajouterplantmalek_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifierplantmalek_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_supprimerplantmalek_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_precedentcaland_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_calpmalek_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_anneesmalek_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_pdispomalek_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_paccueil_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifpval_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_precmodifpmalek_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_precsuppmalek_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_validersuppmalek_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_valider_modif_malek_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_ok_modif_m_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_pas_acc_clicked                     (GtkButton       *button,
                                        gpointer         user_data);


void
on_conf_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_gut_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_tdbf_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_decof_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_ajouterf_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_quitterf_clicked                    (GtkButton       *button,
                                        gpointer         user_data);
