#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif


#include <gtk/gtk.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include"tree.h"
#include"equipement.h"
#include"treeview.h"
#include"troupeaux.h"
#include "fonction.h"
#include "capteur.h"
#include "plante.h"
#include"auth.h"

GtkWidget *acceuil;
GtkWidget *ajouter;
GtkWidget *affiche;
GtkWidget *modifier;
GtkWidget *auth ;
GtkWidget *admin;
GtkWidget *gutilisateurs;

GtkTreeSelection *selection1;
int btnradiomodif=0;
int btnradioajou=0;
int validajou=0;
int validmodif=0;
int btnradiointerface=0;
void
on_AcceuilGestion_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

/*preparation du treeView*/
GtkWidget *p;
gtk_widget_hide (acceuil);
gestion = create_gestion ();

//gtk_widget_show (gestion);
window1=create_window1();
//gtk_widget_show (window1);
p=lookup_widget(window1,"treeview2");
Afficherequipement(p);

window2=create_window2();


 //gtk_widget_show (window2);
window3=create_window3();
// gtk_widget_show (window3);
window4=create_window4();
 gtk_widget_show (window4);
gtk_combo_box_set_active (GTK_COMBO_BOX(lookup_widget(gestion,"combobox1balkis")),0 );
gtk_combo_box_set_active (GTK_COMBO_BOX(lookup_widget(window2,"combobox2balkis")),0 );
}



void
on_Ajouterequipement_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{equipement e;

GtkWidget *entryNom, *entryMarque, *entryReference, *entryType, *entryj, *entrym, *entrya, *entryetat;
GtkWidget *labelnom;
GtkWidget *labelmarque;
GtkWidget *labelreference;
GtkWidget *labeltype;
GtkWidget *labelvalid;

GtkWidget *existe;
GtkWidget* success;
int b=1;

entryNom=lookup_widget(gestion,"entryNombalkis");
entryMarque=lookup_widget(gestion,"entryMarquebalkis");
entryReference=lookup_widget(gestion,"entryReferencebalkis");
entryType=lookup_widget(gestion,"combobox1balkis");
entryj=lookup_widget(gestion,"spinbutton1balkis");
entrym=lookup_widget(gestion,"spinbutton2balkis");
entrya=lookup_widget(gestion,"spinbutton3balkis");


labelnom=lookup_widget(gestion,"label13balkis");
labelmarque=lookup_widget(gestion,"label7balkis");
labelreference=lookup_widget(gestion,"label8balkis");
labeltype=lookup_widget(gestion,"label9balkis");
labelvalid=lookup_widget(gestion,"label91balkis");
existe=lookup_widget(gestion,"label34balkis");
success=lookup_widget(gestion,"label35balkis");

strcpy(e.nom,gtk_entry_get_text(GTK_ENTRY(entryNom)));
strcpy(e.marque,gtk_entry_get_text(GTK_ENTRY(entryMarque) ) );
strcpy(e.reference,gtk_entry_get_text(GTK_ENTRY(entryReference) ) );
strcpy(e.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(entryType) ) );
e.ddf.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entryj));

e.ddf.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entrym));

e.ddf.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entrya));

if (btnradioajou==2){
strcpy(e.etat,"neuf");}
else if (btnradioajou==1){
strcpy(e.etat,"occasion");}
gtk_widget_hide(success);

if(strcmp(e.nom,"")==0){
		  gtk_widget_show (labelnom);
b=0;
}
else {
		  gtk_widget_hide(labelnom);
}

if(strcmp(e.marque,"")==0){
		  gtk_widget_show (labelmarque);
b=0;
}
else {
		  gtk_widget_hide(labelmarque);
}
if(strcmp(e.reference,"")==0){
		  gtk_widget_show (labelreference);
b=0;
}
else {
		  gtk_widget_hide(labelreference);
}
if(strcmp(e.type,"....")==0){
		  gtk_widget_show (labeltype);
b=0;
}
else {
		  gtk_widget_hide(labeltype);
}
gtk_widget_show(labelvalid);
if (validajou==1)
{gtk_widget_hide(labelvalid);
if(b==1)
{

        if(exist_equipement(e.reference)==1)
        {

				  gtk_widget_show (existe);
        }
        else {
						  gtk_widget_hide (existe);
                ajouter_equipement(e);

						  gtk_widget_show (success);

        }

         //  ajouter_equipement(e);

						
        }}}
//mise a jour du treeView
        //GtkWidget* p=lookup_widget(window1,"treeview2");

        //Afficherequipement(p);







void
on_Modifierequipement_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{ equipement e ;
       	 GtkWidget *entryNom, *entryMarque, *entryReference, *entryType, *entryj, *entrym, *entrya, *entryetat,*labelvalid,*success;

entryNom=lookup_widget(window2,"modifNombalkis");
entryMarque=lookup_widget(window2,"modifMarquebalkis");
entryReference=lookup_widget(window2,"label20balkis");
entryType=lookup_widget(window2,"combobox2balkis");
entryj=lookup_widget(window2,"spinbutton4balkis");
entrym=lookup_widget(window2,"spinbutton5balkis");
entrya=lookup_widget(window2,"spinbutton6balkis");
labelvalid=lookup_widget(window2,"label92balkis");
success=lookup_widget(window2,"label37balkis");
 strcpy(e.nom,gtk_entry_get_text(GTK_ENTRY(entryNom) ) );
 strcpy(e.marque,gtk_entry_get_text(GTK_ENTRY(entryMarque) ) );
 strcpy(e.reference,gtk_label_get_text(GTK_LABEL(entryReference) ) );
 strcpy(e.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(entryType) ) );
e.ddf.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entryj));
e.ddf.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entrym));
e.ddf.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entrya));
if (btnradiomodif==2){
strcpy(e.etat,"neuf");}
else if (btnradiomodif==1){
strcpy(e.etat,"occasion");}
gtk_widget_show(labelvalid);
gtk_widget_hide(success);
if (validmodif==1)
{
     

gtk_widget_hide(labelvalid);
gtk_widget_show(success);

        modifier_equipement(e);
}
//Afficherequipement(lookup_widget(window1,"treeview2"));
//mise ajour du tree view 
       //Afficherequipement(lookup_widget(window1,"treeview1"));
	//gtk_widget_show(lookup_widget(window2,"label37"));
        //GtkWidget *p=lookup_widget(window1,"treeview2");
        //Afficherequipement(p);


}




void
on_chercherequipement_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *p1;
GtkWidget *entry;
GtkWidget *labelnom;
GtkWidget *nbResultat;
GtkWidget *message;
char reference[30];
char chnb[30];
int b=0,nb; //b=0  entry  cherche vide 
entry=lookup_widget(window1,"entry10balkis");
labelnom=lookup_widget(window1,"label28balkis");
p1=lookup_widget(window1,"treeview2");
strcpy(reference,gtk_entry_get_text(GTK_ENTRY(entry)));

if(strcmp(reference,"")==0){
  gtk_widget_show (labelnom);b=0;
}else{
b=1;
gtk_widget_hide (labelnom);}

if(b==0)
    {return;
    }
    else
    {

nb=Chercherequipement(p1,"equipement.txt",reference);
// afficher le nombre de resultats obtenue par la recherche */

sprintf(chnb,"%d",nb);        //conversion int==> chaine car la fonction gtk_label_set_text naccepte que chaine
nbResultat=lookup_widget(window1,"label27balkis");
message=lookup_widget(window1,"label26balkis");
gtk_label_set_text(GTK_LABEL(nbResultat),chnb);

gtk_widget_show (nbResultat);
gtk_widget_show (message);



}

}


void
on_GestionAcceuil_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_show (window4);
gtk_widget_hide (gestion);

}




void
on_bmodifier_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
        
}


void
on_bsupprimer_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
    gchar *nom;
    gchar *marque;
    gchar *reference;
    gchar *type;
    gint *j;
    gint *m;
gint *a;
gchar *etat;
    GtkTreeModel     *model;
    GtkTreeIter iter;
       if (gtk_tree_selection_get_selected(selection1, &model, &iter))
        {
            gtk_tree_model_get (model,&iter,0,&nom, 1, &marque, 2, &reference,3,&type,4,&j,5,&m,6,&a,7,&etat,-1);//recuperer les information de la ligne selectionneé
            supprimer_equipement(reference);
            Afficherequipement(lookup_widget(window1,"treeview2"));        
        }
}


void
on_bafficher12_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
Afficherequipement(lookup_widget(window1,"treeview2"));   
}


void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)//signale du treeView (Double click)
{
     gchar *nom;
    gchar *marque;
    gchar *reference;
    gchar *type;
    gint *j;
    gint *m;
gint *a;
gchar *etat;
      
        GtkTreeModel     *model;
        GtkTreeIter iter;
        GtkWidget *p=lookup_widget(window1,"treeview2");
        selection1 = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
       


}



void
on_modifier_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
 char *nom;
    char *marque;
    char *reference;
   char *type;
    int j;
    int m;
int a;
char *etat;

        GtkTreeModel     *model;
GtkWidget     *labelvalid;

        GtkTreeIter iter;
        if (gtk_tree_selection_get_selected(selection1, &model, &iter))
        {

        gtk_widget_hide(lookup_widget(window2,"label37balkis"));//cacher label modifier avec succees
gtk_widget_hide(lookup_widget(window2,"label92balkis"));
                gtk_tree_model_get (model,&iter,0,&nom, 1, &marque, 2, &reference,3,&type,4,&j,5,&m,6,&a,7,&etat,-1);

    gtk_entry_set_text(GTK_ENTRY(lookup_widget(window2,"modifNombalkis")),nom);
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(window2,"modifMarquebalkis")),marque);
             gtk_label_set_text(GTK_ENTRY(lookup_widget(window2,"label20balkis")),reference);
 //gtk_entry_set_text(GTK_ENTRY(lookup_widget(window2,"modifReference")),reference);
if (strcmp(type,"Machine")==0){
gtk_combo_box_set_active (GTK_COMBO_BOX(lookup_widget(window2,"combobox2balkis")),2 );
}
else if (strcmp(type,"Matriel")==0){
gtk_combo_box_set_active (GTK_COMBO_BOX(lookup_widget(window2,"combobox2balkis")),1 );}
		//
gtk_spin_button_set_value(GTK_SPIN_BUTTON(lookup_widget(window2,"spinbutton4balkis")),j);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(lookup_widget(window2,"spinbutton5balkis")),m);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(lookup_widget(window2,"spinbutton6balkis")),a);

if (strcmp(etat,"occasion")==0){
gtk_toggle_button_set_active(GTK_RADIO_BUTTON (lookup_widget(window2,"radiobutton3occmodif")),TRUE);
}
else if (strcmp(etat,"neuf")==0){
gtk_toggle_button_set_active(GTK_RADIO_BUTTON (lookup_widget(window2,"radiobutton3occmodifier")),TRUE);
}
gtk_widget_show (window2);
gtk_widget_hide (window1);

//gtk_combo_box_set_active(GTK_COMBO_BOX(lookup_widget(window2,"combobox2")), );
//radiobutton3occmodif
         // combobox2
//spinbutton4
//spinbutton5
//spinbutton6


                //GtkWidget* msgId=lookup_widget(window2,"label20");
                //GtkWidget* msg1=lookup_widget(window2,"label36");
                
                //gtk_widget_show(msgId);
                //gtk_widget_show(msg1);
                //gtk_widget_show(lookup_widget(window2,"button4"));//afficher le bouton modifier
                //gtk_notebook_prev_page(GTK_NOTEBOOK(lookup_widget(gestion,"notebook1")));//redirection vers la page precedente
       
        }

}


void
on_radiobutton3occmodif_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{btnradiomodif=1;}
}




void
on_checkbutton2confmodif_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_CHECK_BUTTON (togglebutton)))
{validmodif=1;}
else
{validmodif=0;}
}


void
on_radiobuttonoccajout_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{btnradioajou=1;}
}


void
on_radiobutton2neufajou_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{btnradioajou=2;}
}




void
on_checkbutton1ajout_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_CHECK_BUTTON (togglebutton)))
{validajou=1;}
else
{validajou=0;}
}


void
on_radiobutton3occmodifier_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{btnradiomodif=2;}
}


void
on_eqAfficher_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_show (window1);
gtk_widget_hide (gestion);
Afficherequipement(lookup_widget(window1,"treeview2"));   
}


void
on_ouisupp_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_nonsup_clicked                      (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_modifretour_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_show (window1);
gtk_widget_hide (window2);

}


void
on_treeretourr_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_show (window4);
gtk_widget_hide (window1);
}


void
on_modifaffich_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_show (window1);
gtk_widget_hide (window2);
Afficherequipement(lookup_widget(window1,"treeview2"));
}


void
on_buttonradioajou_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{btnradiointerface=1;}

}


void
on_radiobutton2affich_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{btnradiointerface=2;}
}


void
on_button11_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
if (btnradiointerface==2)
{gtk_widget_show (window1);
gtk_widget_hide (window4);}
else
if (btnradiointerface==1)
{gtk_widget_show (gestion);
gtk_widget_hide (window4);

}
}


void
on_treeajou_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_show (gestion);
gtk_widget_hide (window1);
}


void
on_treeview2TR_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *identifiant;
    gchar *type;
    gchar *sexe;
    gchar *etat;
    gint *j;
    gint *m;
    gint *a;
        GtkTreeModel     *model;
        GtkTreeIter iter;
        GtkWidget *p=lookup_widget(affiche,"treeview2hou");
        selection1 = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
}


void
on_TRtreeretourr_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_show (acceuil);
gtk_widget_hide (affiche);
}


void
on_TRtreeajou_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
ajouter = create_ajouter ();
gtk_widget_show (ajouter);
gtk_widget_hide (affiche);
}


void
on_TRbutton6_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *p1;
GtkWidget *entry;
GtkWidget *labelidentifiant;
GtkWidget *nbResultat;
GtkWidget *message;
char identifiant[30];
char chnb[30];
int b=0,nb;
entry=lookup_widget(affiche,"entry10hou");
labelidentifiant=lookup_widget(affiche,"label28hou");
p1=lookup_widget(affiche,"treeview2hou");
strcpy(identifiant,gtk_entry_get_text(GTK_ENTRY(entry)));

if(strcmp(identifiant,"")==0){
  gtk_widget_show (labelidentifiant);b=0;
}else{
b=1;
gtk_widget_hide (labelidentifiant);}

if(b==0)
    {return;
    }
    else
    {

nb=Cherchertroupeaux(p1,"troupeaux.txt",identifiant);
// afficher le nombre de resultats obtenue par la recherche */

sprintf(chnb,"%d",nb);        //conversion int==> chaine car la fonction gtk_label_set_text naccepte que chaine
nbResultat=lookup_widget(affiche,"label27hou");
message=lookup_widget(affiche,"label3hou");
gtk_label_set_text(GTK_LABEL(nbResultat),chnb);

gtk_widget_show (nbResultat);
gtk_widget_show (message);
}

}


void
on_TRbmodifier_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
char *identifiant;
    char *type;
    char *sexe;
   char *etat;
    int j;
    int m;
    int a;
modifier=create_modifier();
        GtkTreeModel     *model;
GtkWidget     *labelvalid;

        GtkTreeIter iter;
        if (gtk_tree_selection_get_selected(selection1, &model, &iter))
        {

        gtk_widget_hide(lookup_widget(modifier,"label52hou"));//cacher label modifier avec succees
gtk_widget_hide(lookup_widget(modifier,"label48hou"));
                gtk_tree_model_get (model,&iter,0,&identifiant, 1, &type, 2, &sexe,3,&etat,4,&j,5,&m,6,&a,-1);
           gtk_label_set_text(GTK_ENTRY(lookup_widget(modifier,"label54hou")),identifiant);
 //gtk_entry_set_text(GTK_ENTRY(lookup_widget(window2,"modifReference")),reference);
if (strcmp(type,"Veau")==0){
gtk_combo_box_set_active (GTK_COMBO_BOX(lookup_widget(modifier,"combobox3hou")),2 );
}
else if (strcmp(type,"Brebi")==0){
gtk_combo_box_set_active (GTK_COMBO_BOX(lookup_widget(modifier,"combobox3hou")),1 );}

if (strcmp(sexe,"Femelle")==0){
gtk_combo_box_set_active (GTK_COMBO_BOX(lookup_widget(modifier,"combobox4hou")),2 );
}
else if (strcmp(sexe,"Mâle")==0){
gtk_combo_box_set_active (GTK_COMBO_BOX(lookup_widget(modifier,"combobox4hou")),1 );}

gtk_spin_button_set_value(GTK_SPIN_BUTTON(lookup_widget(modifier,"spinbutton5hou")),j);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(lookup_widget(modifier,"spinbutton4hou")),m);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(lookup_widget(modifier,"spinbutton6hou")),a);

if (strcmp(etat,"Malade")==0){
gtk_toggle_button_set_active(GTK_RADIO_BUTTON (lookup_widget(modifier,"MaladeModif")),TRUE);
}
else if (strcmp(etat,"BonSanté")==0){
gtk_toggle_button_set_active(GTK_RADIO_BUTTON (lookup_widget(modifier,"BonsantéModif")),TRUE);
}
gtk_widget_show (modifier);
gtk_widget_hide (affiche);
  }

}



void
on_calculenor_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *resultat;
GtkWidget *calcul;
int s=0;

Troupeau t;
char type[30];
FILE *f;
resultat=lookup_widget(affiche,"label120");
calcul=lookup_widget(affiche,"combobox1");
strcpy(t.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(calcul) ) );
calculer(type);
gtk_label_set_text(GTK_LABEL(resultat),"le nombre de troupeaux de ce type est ");
}


void
on_TRbsupprimer_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
{
    gchar *identifiant;
    gchar *type;
    gchar *sexe;
    gchar *etat;
    gint *j;
    gint *m;
    gint *a;
    GtkTreeModel     *model;
    GtkTreeIter iter;
       if (gtk_tree_selection_get_selected(selection1, &model, &iter))
        {
            gtk_tree_model_get (model,&iter,0,&identifiant, 1, &type, 2, &sexe,3,&etat,4,&j,5,&m,6,&a,-1);//recuperer les information de la ligne selectionneé
            supprimer_troupeaux(identifiant);
            Affichertroupeaux(lookup_widget(affiche,"treeview2hou"));        
        }
}

}


void
on_TRbafficher12_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *nbResultat;
GtkWidget *message;
nbResultat=lookup_widget(affiche,"label27hou");
message=lookup_widget(affiche,"label3hou");

Affichertroupeaux(lookup_widget(affiche,"treeview2hou"));
gtk_widget_hide (nbResultat);
gtk_widget_hide (message);

}

void
on_TRbutton19_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_show (acceuil);
gtk_widget_hide (affiche);
}


void
on_TRRetourAffich_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_show (affiche);
gtk_widget_hide (ajouter);
}


void
on_TRQuitAjouter_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_show (affiche);
gtk_widget_hide (ajouter);
}


void
on_TRAjouterTroupeaux_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
Troupeau t;

GtkWidget *entryidentifiant, *entrtype, *entrysexe, *entryetat, *entryj, *entrym, *entrya; 
GtkWidget *labelidentifiant;
GtkWidget *labeltype;
GtkWidget *labelsexe;
GtkWidget *labelvalid;

GtkWidget *existe;
GtkWidget* success;
int b=1;

entryidentifiant=lookup_widget(button,"entry11hou");
entrtype=lookup_widget(button,"combobox1hou");
entrysexe=lookup_widget(button,"combobox2hou");
entryj=lookup_widget(button,"spinbutton1hou");
entrym=lookup_widget(button,"spinbutton2hou");
entrya=lookup_widget(button,"spinbutton3hou");


labelidentifiant=lookup_widget(button,"label36hou");
labeltype=lookup_widget(button,"label37hou");
labelsexe=lookup_widget(button,"label38hou");
labelvalid=lookup_widget(button,"label39hou");
existe=lookup_widget(button,"label34hou");
success=lookup_widget(button,"label35hou");

strcpy(t.identifiant,gtk_entry_get_text(GTK_ENTRY(entryidentifiant)));
strcpy(t.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(entrtype) ) );
strcpy(t.sexe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(entrysexe) ) );

t.date.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entryj));

t.date.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entrym));

t.date.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entrya));

if (btnradioajou==2){
strcpy(t.etat,"BonSanté");}
else if (btnradioajou==1){
strcpy(t.etat,"Malade");}
gtk_widget_hide(success);

if(strcmp(t.identifiant,"")==0){
		  gtk_widget_show (labelidentifiant);
b=0;
}
else {
		  gtk_widget_hide(labelidentifiant);
}

if(strcmp(t.type,"...")==0){
		  gtk_widget_show (labeltype);
b=0;
}
else {
		  gtk_widget_hide(labeltype);
}
if(strcmp(t.sexe,"...")==0){
		  gtk_widget_show (labelsexe);
b=0;
}
else {
		  gtk_widget_hide(labelsexe);
}

gtk_widget_show(labelvalid);
if (validajou==1)
{gtk_widget_hide(labelvalid);
if(b==1)
{

        if(exist_troupeaux(t.identifiant)==1)
        {

				  gtk_widget_show (existe);
        }
        else {
						  gtk_widget_hide (existe);
               

						  gtk_widget_show (success);

        ajouter_troupeaux(t); }

        

						
        }}

 }



void
on_TRtrouAfficher_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
affiche=create_affiche();
gtk_widget_show (affiche);
gtk_widget_hide (ajouter);
Affichertroupeaux(lookup_widget(affiche,"treeview2hou")); 
}


void
on_Bonsant___toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{btnradioajou=2;}
}


void
on_TRcheckbutton1ajout_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_CHECK_BUTTON (togglebutton)))
{validajou=1;}
else
{validajou=0;}
}


void
on_Malade_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{btnradioajou=1;}
}


void
on_MaladeModif_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{btnradiomodif=1;}
}


void
on_Bonsant__Modif_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{btnradiomodif=2;}
}


void
on_TRbutton24_retourM_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_show (affiche);
gtk_widget_hide (modifier);
}


void
on_TRbutton22_quit_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_show (affiche);
gtk_widget_hide (modifier);
}


void
on_TRModifiertrou_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

Troupeau t ;
       	 GtkWidget *entryidentifiant, *entrtype, *entrysexe, *entryetat, *entryj, *entrym, *entrya, *labelvalid,*success;

entryidentifiant=lookup_widget(modifier,"label54hou");
entrtype=lookup_widget(modifier,"combobox3hou");
entrysexe=lookup_widget(modifier,"combobox4hou");
entryj=lookup_widget(modifier,"spinbutton5hou");
entrym=lookup_widget(modifier,"spinbutton4hou");
entrya=lookup_widget(modifier,"spinbutton6hou");
labelvalid=lookup_widget(modifier,"label48hou");
success=lookup_widget(modifier,"label52hou");
 strcpy(t.identifiant,gtk_label_get_text(GTK_LABEL(entryidentifiant) ) );
 strcpy(t.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(entrtype) ) );
 strcpy(t.sexe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(entrysexe) ) );

t.date.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entryj));
t.date.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entrym));
t.date.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entrya));
if (btnradiomodif==2){
strcpy(t.etat,"BonSanté");}
else if (btnradiomodif==1){
strcpy(t.etat,"Malade");}
gtk_widget_show(labelvalid);
gtk_widget_hide(success);
if (validmodif==1)
{
     

gtk_widget_hide(labelvalid);
gtk_widget_show(success);

        modifier_troupeaux(t);
}
}


void
on_TRModifAffich_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_show (affiche);
gtk_widget_hide (modifier);
Affichertroupeaux(lookup_widget(affiche,"treeview2hou"));
}


void
on_GestionTroupeaux_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *p;
gtk_widget_hide (acceuil);
affiche=create_affiche();
gtk_widget_show (affiche);
p=lookup_widget(affiche,"treeview2hou");
Affichertroupeaux(p);
}


void
on_TRcheckbutton2_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_CHECK_BUTTON (togglebutton)))
{validmodif=1;}
else
{validmodif=0;}
}


void
on_TRRetourAffiche_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_show (affiche);
gtk_widget_hide (ajouter);
}

//navigation

void
on_gestionouvries_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *p,  *p2 ,*p3;
GtkWidget *window5;
window5=create_window5();
gtk_widget_show (window5);

p=lookup_widget(window5,"treeview1");

p2=lookup_widget(window5,"treeview2");
p3=lookup_widget(window5,"treeview3");

Afficherouvrier(p,"users.txt");
Afficherouvrier1(p2,"users.txt");
afficherabsence(p3,"absenteisme.txt");

}


void
on_gestioncapteur_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window6;
window6=create_window6();
gtk_widget_show (window6);
}


void
on_gestionstock_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}



//gestion ouvrier 


int btnradioconv=0;



void
on_gestionouvrier_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *p,  *p2 ,*p3;
GtkWidget *window2, *windowo;

windowo= create_window1();


p=lookup_widget(windowo,"treeview1");

p2=lookup_widget(windowo,"treeview2");
p3=lookup_widget(windowo,"treeview3");

Afficherouvrier(p,"users.txt");
Afficherouvrier1(p2,"users.txt");
afficherabsence(p3,"absenteisme.txt");



window2=lookup_widget(button,"window2");

gtk_widget_hide(window2);
gtk_widget_show(windowo);

}



void
on_quitter_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_ajouter_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget  *entrycin, *entrynom, *entryprenom, *entrynumtel, *entrysalaire, *entrysexe, *CIN, *NOM, *PRENOM, *TEL ,*success , *fail , *p ,*p2 ,*p3, *p4; 

ouvrier o ;
absenteisme a ;
a.pjan =0;
a.pfev =0;
a.pmar =0;
a.pav=0;
a.pmai=0;
a.pjuin=0;
a.pjuil=0;
a.paout=0;
a.psept=0;
a.poct=0;
a.pnov=0;
a.pdec=0; 


p=lookup_widget(button,"treeview1");
p3=lookup_widget(button,"treeview2");
p4=lookup_widget(button,"treeview3");
//entries
entrycin=lookup_widget(button,"entrycin");
entrynom=lookup_widget(button,"entrynom");
entryprenom=lookup_widget(button,"entryprenom");
entrynumtel=lookup_widget(button,"entrytel");
entrysalaire=lookup_widget(button,"spinbuttonsalaire");
entrysexe=lookup_widget(button,"comboboxsexe");


//labels

CIN=lookup_widget(button,"cin");
NOM=lookup_widget(button,"nom");
PRENOM=lookup_widget(button,"prenom");
TEL=lookup_widget(button,"tel");
fail=lookup_widget(button,"labelexiste");
success=lookup_widget(button,"label11");

//récuperation des données 

strcpy(o.cin, gtk_entry_get_text(GTK_ENTRY(entrycin)));
strcpy(o.nom, gtk_entry_get_text(GTK_ENTRY(entrynom)));
strcpy(o.prenom, gtk_entry_get_text(GTK_ENTRY(entryprenom)));
strcpy(o.tel, gtk_entry_get_text(GTK_ENTRY(entrynumtel)));
strcpy(o.sexe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(entrysexe)));
o.salaire=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entrysalaire));
strcpy(a.nom, gtk_entry_get_text(GTK_ENTRY(entrynom)));
strcpy(a.cin, gtk_entry_get_text(GTK_ENTRY(entrycin)));


//controle de saisie 
if(strcmp(o.cin,"")==0)
{
gtk_widget_show(CIN);
gtk_widget_set_visible(success,FALSE);

}
else
{
gtk_widget_set_visible(CIN,FALSE);
gtk_widget_set_visible(success,FALSE);

}
if(strcmp(o.nom,"")==0)
{
gtk_widget_show(NOM);
gtk_widget_set_visible(success,FALSE);

}
else
{
gtk_widget_set_visible(NOM,FALSE);
gtk_widget_set_visible(success,FALSE);

}

if(strcmp(o.prenom,"")==0)
{
gtk_widget_show(PRENOM);
gtk_widget_set_visible(success,FALSE);

}
else
{
gtk_widget_set_visible(PRENOM,FALSE);
gtk_widget_set_visible(success,FALSE);
}

if(strcmp(o.tel,"")==0)
{
gtk_widget_show(TEL);
gtk_widget_set_visible(success,FALSE);

}
else
{
gtk_widget_set_visible(TEL,FALSE);
gtk_widget_set_visible(success,FALSE);

}
if(gtk_widget_get_visible(CIN)==FALSE && gtk_widget_get_visible(NOM)==FALSE && gtk_widget_get_visible(PRENOM)==FALSE && gtk_widget_get_visible(TEL)==FALSE)
{
         if(exist(o.cin)==1)
{
	gtk_widget_set_visible(success,FALSE);
	gtk_widget_show(fail);
        Afficherouvrier (p,"users.txt");
        Afficherouvrier1(p3,"users.txt");
        afficherabsence(p4,"absenteisme.txt");
}
       

 else {

	
         ajouter_ov(o,a);
         //bien ajouté 
	gtk_widget_set_visible(fail,FALSE);
	gtk_widget_show(success);
	//vider les champs après ajout
	gtk_entry_set_text(GTK_ENTRY(entrycin),"");
	gtk_entry_set_text(GTK_ENTRY(entrynom),"");
	gtk_entry_set_text(GTK_ENTRY(entryprenom),"");
        gtk_entry_set_text(GTK_ENTRY(entrynumtel),"");
	gtk_spin_button_set_value(GTK_SPIN_BUTTON(entrysalaire),500);
        //mise à jour du treeview 
       p2=lookup_widget(button,"treeview1");
	Afficherouvrier(p2,"users.txt");
        Afficherouvrier1(p3,"users.txt");
        afficherabsence(p4,"absenteisme.txt");
	}
}
}



void
on_treeview_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{


}

void
on_modifier2_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkTreeSelection *selection;
        GtkTreeModel     *model;
        GtkTreeIter iter;
        gchar* cin;
GtkWidget *entrynom, *entryprenom,*labelvalid, *entrytel, *entrysexe, *entrysalaire, *success,  *p , *p2;
ouvrier ov;

//les labels
success=lookup_widget(button,"success");

//entries

entrynom=lookup_widget(button,"entrynom1");
entryprenom=lookup_widget(button,"entryprnom1");
entrytel=lookup_widget(button,"entrytel1");
entrysalaire=lookup_widget(button,"spinbuttonsalaire2");
entrysexe=lookup_widget(button,"comboboxsexe2");
labelvalid=lookup_widget(button,"labelvalid");


//Récuperation 
strcpy(ov.nom, gtk_entry_get_text(GTK_ENTRY(entrynom)));


strcpy(ov.prenom, gtk_entry_get_text(GTK_ENTRY(entryprenom)));
strcpy(ov.tel, gtk_entry_get_text(GTK_ENTRY(entrytel)));
ov.salaire=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entrysalaire));
strcpy(ov.sexe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(entrysexe)));

         p2=lookup_widget(button,"treeview2");
	p=lookup_widget(button,"treeview1");
        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {  
		
                gtk_tree_model_get (model,&iter,0,&cin,-1);
		gtk_widget_show(labelvalid);
                modifier_ov(ov, cin );
		//mise à jour du treeview
		Afficherouvrier(p,"users.txt");
                Afficherouvrier1(p2,"users.txt");
		if (validmodif==1)
		{
		//bien modifié
		gtk_widget_hide(labelvalid);
		gtk_widget_show(success);}
		//vider les champs après modification
		gtk_entry_set_text(GTK_ENTRY(entrynom),"");
		gtk_entry_set_text(GTK_ENTRY(entryprenom),"");
		gtk_entry_set_text(GTK_ENTRY(entrytel),"");
		gtk_spin_button_set_value(GTK_SPIN_BUTTON(entrysalaire),500);
		
		}
}


void
on_supprimer1_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkTreeSelection *selection;
        GtkTreeModel     *model;
        GtkTreeIter iter;
        GtkWidget* p1  , *p2;
        gchar* cin;

        p1=lookup_widget(button,"treeview1");
        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p1));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {  gtk_tree_model_get (model,&iter,0,&cin,-1);
           gtk_list_store_remove(GTK_LIST_STORE(model),&iter);//supprimer la ligne du treeView

          supprimer(cin);
          p2=lookup_widget(button,"treeview2");
          Afficherouvrier1(p2,"users.txt");
        }

}

void
on_chercher_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *p1;
GtkWidget *entry;
GtkWidget *labelnom;
GtkWidget *nbResultat;
GtkWidget *message;
char nom[30];
char chnb[30];
int b=0,nb;
entry=lookup_widget(button,"entrynom2");
labelnom=lookup_widget(button,"labelnom2");
p1=lookup_widget(button,"treeview2");
strcpy(nom,gtk_entry_get_text(GTK_ENTRY(entry)));

if(strcmp(nom,"")==0)
{
  gtk_widget_show (labelnom);b=0;
}
else
{
b=1;
gtk_widget_hide (labelnom);
}

if(b==0)
{
return;
}
else
{

nb=Chercherouvrier(p1,"users.txt",nom);
/* afficher le nombre de resultats obtenue par la recherche */
sprintf(chnb,"%d",nb);//conversion int==> chaine car la fonction gtk_label_set_text naccepte que chaine
nbResultat=lookup_widget(button,"nb");
message=lookup_widget(button,"msgres");
gtk_label_set_text(GTK_LABEL(nbResultat),chnb);

gtk_widget_show (nbResultat);
gtk_widget_show (message);

}
}


void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_buttonvalider_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkTreeSelection *selection;
        GtkTreeModel     *model;
        GtkTreeIter iter;
        gchar* cin;
GtkWidget *entrymois, *prst,  *p ;
absenteisme a;
char mois[30], presence[30];


p=lookup_widget(button,"treeview3");
selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {  
		
                gtk_tree_model_get (model,&iter,0,&cin,-1);}
recuperer(a,cin);

prst=lookup_widget(button,"comboboxentry4");
entrymois=lookup_widget(button,"comboboxmois");



strcpy(mois,gtk_combo_box_get_active_text(GTK_COMBO_BOX(entrymois)));
strcpy(presence,gtk_combo_box_get_active_text(GTK_COMBO_BOX(prst)));


if (strcmp (presence,"Absent(e)")==0 && strcmp(mois,"Janvier")==0 ){
          
                a.pjan= a.pjan+1;}


else  {a.pjan=a.pjan;} 



if(  strcmp (presence,"Absent(e)")==0       &&  strcmp(mois,"Fevrier")==0)
               {a.pfev=a.pfev+1;}


else {a.pfev=a.pfev;}
 



if(strcmp (presence,"Absent(e)")==0   && strcmp(mois,"Mars")==0)
                              {a.pmar=a.pmar+1;}
else 

         {a.pmar=a.pmar;}
     

if (strcmp (presence,"Absent(e)")==0 && strcmp(mois,"Avril")==0)
                      {a.pav=a.pav+1;}

      else 
                 {a.pav=a.pav;}

 

if(strcmp (presence,"Absent(e)")==0   && strcmp(mois,"Mai")==0)
               {a.pmai=a.pmai+1;}
else       
               {a.pmai=a.pmai;}


if(strcmp (presence,"Absent(e)")==0     && strcmp(mois,"Juin")==0)
               {a.pjuin=a.pjuin+1;}

else       {a.pjuin=a.pjuin;}

if(strcmp (presence,"Absent(e)")==0    && strcmp(mois,"Juillet")==0)
               {a.pjuil=a.pjuil + 1 ;}

else
             {a.pjuil=a.pjuil;}

if(strcmp (presence,"Absent(e)")==0         && strcmp(mois,"Aout")==0)

               {a.paout=a.paout+1;} 

else                {a.paout=a.paout;} 
             
 
if(strcmp (presence,"Absent(e)")==0    && strcmp(mois,"Septembre")==0)
               {a.psept=a.psept+1;} 
    
else     {a.psept=a.psept ;}

if(strcmp (presence,"Absent(e)")==0  &&  strcmp(mois,"October")==0)
               {a.poct=a.poct+1;}
else             {a.poct=a.poct;}

if(strcmp (presence,"Absent(e)")==0      &&  strcmp(mois,"Novembre")==0)
               {a.pnov=a.pnov+1;}
else     {a.pnov=a.pnov;}


if(strcmp (presence,"Absent(e)")==0   && strcmp(mois,"Decembre")==0)
               {a.pdec=a.pdec+1;}
else 
                    {a.pdec=a.pdec;}



    
                
                marquer(a,cin );
		//mise à jour du treeview
		
		afficherabsence(p,"absenteisme.txt");

}


void
on_radiobuttonoui_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{btnradioconv=1;}
}


void
on_radiobuttonnon_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{btnradioconv=2;}
}


void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_CHECK_BUTTON (togglebutton)))
{validmodif=1;}
else
{validmodif=0;}
}

//capteur



void
on_button_ajoute_cap_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
int a;
           capteur c;
        GtkWidget *input1,*input2,*input3,*combobox1,*input5,*input6;
        GtkWidget *output1;
        
        input1=lookup_widget(objet_graphique,"entry1");
        input2=lookup_widget(objet_graphique,"entry2");
        input3=lookup_widget(objet_graphique,"entry4");
	combobox1=lookup_widget(objet_graphique,"combobox1");
        input5=lookup_widget(objet_graphique,"entry3");
        input6=lookup_widget(objet_graphique,"entry10");
        output1=lookup_widget(objet_graphique,"label5");
	
        strcpy(c.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
        strcpy(c.id,gtk_entry_get_text(GTK_ENTRY(input2)));
        strcpy(c.mark,gtk_entry_get_text(GTK_ENTRY(input3)));
        strcpy(c.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
	strcpy(c.prix,gtk_entry_get_text(GTK_ENTRY(input5)));
	strcpy(c.date,gtk_entry_get_text(GTK_ENTRY(input6)));
	
        
        
	
        if ((strlen(c.id)==0)||(strlen(c.mark)==0)||(strlen(c.prix)==0) || (strlen(c.nom)==0) ||(strlen(c.date)==0) )
{

       gtk_label_set_text(GTK_LABEL(output1),"veuilez remplir toutes les cases");
}
else
{
        a=ajouter_capteur(c);
        if (a==0){
       
        gtk_label_set_text(GTK_LABEL(output1),"ajout avec succés");
       }
       else  
      {
       gtk_label_set_text(GTK_LABEL(output1),"membre deja existant");
       }
}

}


void
on_button_annul_ajt_cap_clicked        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *input1,*input2,*input3,*combobox1,*input5,*input6;
        GtkWidget *output1;
        
        input1=lookup_widget(objet_graphique,"entry1");
        input2=lookup_widget(objet_graphique,"entry2");
        input3=lookup_widget(objet_graphique,"entry3");
	//combobox1=lookup_widget(objet_graphique,"combobox1");
        input5=lookup_widget(objet_graphique,"entry4");
        input6=lookup_widget(objet_graphique,"entry10");


    gtk_entry_set_text(GTK_ENTRY(input1),"");
    gtk_entry_set_text(GTK_ENTRY(input2),"");
    gtk_entry_set_text(GTK_ENTRY(input3),"");
    gtk_entry_set_text(GTK_ENTRY(input5),"");
    gtk_entry_set_text(GTK_ENTRY(input6),"");
    //gtk_combo_box_get_active_text(Gtk_ComboBox(combobox1),"");

}


void
on_button_rech_mod_cap_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	char nom[30];
	char id[30];
	char type[30];
	char mark[30];
	char date[30];
	char prix[30]; 
   int x;
   GtkWidget *input;
   GtkWidget *output;
   input=lookup_widget(objet_graphique,"entry5");
   strcpy(id,gtk_entry_get_text(GTK_ENTRY(input)));
   x=recherche_capteur(id);
   output=lookup_widget(objet_graphique,"label19");
 if ((strlen(id)==0))
{
       gtk_label_set_text(GTK_LABEL(output),"veuilez remplir la case");
}
else 
{
   if (x==1)
{
   gtk_label_set_text(GTK_LABEL(output),"membre non existant");
  
}
else
{
  
  gtk_label_set_text(GTK_LABEL(output),id);
}
}
}


void
on_button_modif_cap_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
capteur c; 
        GtkWidget *input1, *input2,*input3,*combobox1,*input5,*input6;
        GtkWidget *output,*output1,*output2;
        
        input1=lookup_widget(objet_graphique,"entry5");
        input2=lookup_widget(objet_graphique,"entry6");
        input3=lookup_widget(objet_graphique,"entry7");
	combobox1=lookup_widget(objet_graphique,"combobox2");
        input5=lookup_widget(objet_graphique,"entry8");
        input6=lookup_widget(objet_graphique,"entry11");
        output1=lookup_widget(objet_graphique,"label19");
        
        strcpy(c.id,gtk_label_get_text(GTK_LABEL(output1)));
        strcpy(c.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
        strcpy(c.mark,gtk_entry_get_text(GTK_ENTRY(input3)));
        strcpy(c.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
        strcpy(c.prix,gtk_entry_get_text(GTK_ENTRY(input5)));
	strcpy(c.date,gtk_entry_get_text(GTK_ENTRY(input6)));
	
         modifier_capteur(c);
    
    output2=lookup_widget(objet_graphique,"label17"); 
        if ((strlen(c.id)==0)||(strlen(c.mark)==0)||(strlen(c.prix)==0) || (strlen(c.nom)==0) ||(strlen(c.date)==0) )
        
{
       gtk_label_set_text(GTK_LABEL(output2),"veuilez remplir toutes les cases");
}
else
{
     
     
     gtk_label_set_text(GTK_LABEL(output2),"modifié avec succés");
}
}


void
on_button_annul_modif_cap_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *input1,*input2,*input3,*combobox1,*input5,*input6;
        GtkWidget *output1;
        
        input1=lookup_widget(objet_graphique,"entry5");
        input2=lookup_widget(objet_graphique,"entry6");
        input3=lookup_widget(objet_graphique,"entry7");
	//combobox1=lookup_widget(objet_graphique,"combobox1");
        input5=lookup_widget(objet_graphique,"entry8");
        input6=lookup_widget(objet_graphique,"entry11");


    gtk_entry_set_text(GTK_ENTRY(input1),"");
    gtk_entry_set_text(GTK_ENTRY(input2),"");
    gtk_entry_set_text(GTK_ENTRY(input3),"");
    gtk_entry_set_text(GTK_ENTRY(input5),"");
    //gtk_ComboBox_set_text(Gtk_ComboBox(input5),"");

}


void
on_button_affich_cap_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *treeview;
        GtkWidget *window1;
        window1=lookup_widget(objet_graphique,"window8");
        treeview=lookup_widget(objet_graphique,"treeview1");
        
        afficher_capteur(treeview);

}


void
on_button_rech_sup_cap_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
char nom[30];
	char id[30];
	char type[30];
	char mark[30];
	char date[30];
	char prix[30]; 
   int x;
   GtkWidget *input;
   GtkWidget *output;
   input=lookup_widget(objet_graphique,"entry9");
   strcpy(id,gtk_entry_get_text(GTK_ENTRY(input)));
   x=recherche_capteur(id);
   output=lookup_widget(objet_graphique,"label30");
 if ((strlen(id)==0))
{
       gtk_label_set_text(GTK_LABEL(output),"veuilez remplir la case");
}
else 
{
   if (x==1)
{
   gtk_label_set_text(GTK_LABEL(output),"membre non existant");
  
}
else
{
  
  gtk_label_set_text(GTK_LABEL(output),id); 
}
}
}


void
on_button_sup_cap_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	
GtkWidget *input;
GtkWidget *output;
capteur c;
char ref[20];
input=lookup_widget(objet_graphique,"entry9");
output=lookup_widget(objet_graphique,"label28");
strcpy(ref,gtk_entry_get_text(GTK_ENTRY(input)));
if(strcmp(ref,c.id)==0)
gtk_label_set_text(GTK_LABEL(output),"capteur n'existe pas");
else
{
supprimer_capteur(ref);
gtk_label_set_text(GTK_LABEL(output),"suppression avec succée");
}
}


void
on_button50_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1 ;
 GtkWidget *window2;

window1=lookup_widget(objet_graphique,"window8");
gtk_widget_hide(window1);
window2 = create_window6();
gtk_widget_show (window2);
}


void
on_button51_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1 ;
 GtkWidget *window2;

window1=lookup_widget(objet_graphique,"window8");
gtk_widget_hide(window1);
window2 = create_window7();
gtk_widget_show (window2);
}


void
on_button52_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1 ;
 GtkWidget *window2;

window1=lookup_widget(objet_graphique,"window8");
gtk_widget_hide(window1);
window2 = create_window9();
gtk_widget_show (window2);
}


void
on_button12_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *window1 ;
 GtkWidget *window2;

window1=lookup_widget(objet_graphique,"window6");
gtk_widget_hide(window1);
window2 = create_window8();
gtk_widget_show (window2);
}


void
on_button13_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1 ;
 GtkWidget *window2;

window1=lookup_widget(objet_graphique,"window7");
gtk_widget_hide(window1);
window2 = create_window8();
gtk_widget_show (window2);

}


void
on_button56_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1 ;
 GtkWidget *window2;

window1=lookup_widget(objet_graphique,"window9");
gtk_widget_hide(window1);
window2 = create_window8();
gtk_widget_show (window2);
}

//gestion stock




void
on_ajouterpmalek_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_chercherpmalek_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_supprimerpmalek_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_ajouterplantmalek_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *calendrier,*treeview_cal;
GtkWidget *valider_modif_malek,*nomplantemalek,*supprimerplantmalek,*modifierplantmalek,*jourpmalek,*jourrmalek,*qtemalek,*moispmalek,*moisrmalek,*anneepmalek,*annermalek,*label1,*label2,*label3;


nomplantemalek= lookup_widget(button,"nomplantemalek");
gtk_widget_show(nomplantemalek);

jourpmalek= lookup_widget(button,"jourpmalek");
gtk_widget_show(jourpmalek);

jourrmalek= lookup_widget(button,"jourrmalek");
gtk_widget_show(jourrmalek);

moispmalek= lookup_widget(button,"moispmalek");
gtk_widget_show(moispmalek);

moisrmalek= lookup_widget(button,"moisrmalek");
gtk_widget_show(moisrmalek);

anneepmalek= lookup_widget(button,"anneepmalek");
gtk_widget_show(anneepmalek);

annermalek= lookup_widget(button,"annermalek");
gtk_widget_show(annermalek);

qtemalek= lookup_widget(button,"qtemalek");
gtk_widget_show(qtemalek);

label1= lookup_widget(button,"label7");
gtk_widget_show(label1);

label2= lookup_widget(button,"label8");
gtk_widget_show(label2);

label3= lookup_widget(button,"label19");
gtk_widget_show(label3);

valider_modif_malek= lookup_widget(button,"valider_modif_malek");
gtk_widget_show(valider_modif_malek);

supprimerplantmalek= lookup_widget(button,"supprimerplantmalek");
gtk_widget_hide(supprimerplantmalek);
modifierplantmalek= lookup_widget(button,"modifierplantmalek");
gtk_widget_hide(modifierplantmalek);

treeview_cal=lookup_widget(button,"treeview_cal");
gtk_widget_hide(treeview_cal);

}


void
on_modifierplantmalek_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *modifpmalek;
GtkWidget *calendrier;

calendrier=lookup_widget(button,"calendrierpmalek");
modifpmalek= lookup_widget(button,"modifpmalek"); 
gtk_widget_destroy(calendrier);
modifpmalek=create_modifpmalek();
gtk_widget_show(modifpmalek);

}


void
on_supprimerplantmalek_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *supprimerpmalek;
GtkWidget *calendrier;

calendrier=lookup_widget(button,"calendrierpmalek");
supprimerpmalek= lookup_widget(button,"supprimerpmalek"); 
gtk_widget_destroy(calendrier);
supprimerpmalek=create_supprimerpmalek();
gtk_widget_show(supprimerpmalek);


}


void
on_precedentcaland_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *accueil;
GtkWidget *calendrier;

calendrier=lookup_widget(button,"calendrierpmalek");//calendrier pointe vers la fenetre calendrierpmalek
accueil= lookup_widget(button,"accueilmalek"); //accueil pointe vers la fenetre accueilmalek
gtk_widget_destroy(calendrier);
accueil=create_acceuil();
gtk_widget_show(accueil);

}


void
on_calpmalek_clicked                   (GtkButton       *button,
                                        gpointer         user_data)  	//ce bout de code ci dessous permet de se déplacer d'une fenetre à une autre, avec un peu de modification au niveau des variables on est libre de se deplacer librement entre les fentres désirées
{
GtkWidget *accueil;
GtkWidget *calendrier,*treeview_cal,*ok_modif_m;
GtkWidget *valider_modif_malek,*nomplantemalek,*jourpmalek,*jourrmalek,*qtemalek,*moispmalek,*moisrmalek,*anneepmalek,*annermalek,*label1,*label2,*label3;

accueil= lookup_widget(button,"accueilmalek"); //accueil pointe vers la fenetre accueilmalek
gtk_widget_destroy(accueil);



calendrier=lookup_widget(button,"calendrierpmalek");//calendrier pointe vers la fenetre calendrierpmalek
calendrier=create_calendrierpmalek();

nomplantemalek= lookup_widget(calendrier,"nomplantemalek");
gtk_widget_hide(nomplantemalek);

ok_modif_m= lookup_widget(calendrier,"ok_modif_m");
gtk_widget_hide(ok_modif_m);

jourpmalek= lookup_widget(calendrier,"jourpmalek");
gtk_widget_hide(jourpmalek);

jourrmalek= lookup_widget(calendrier,"jourrmalek");
gtk_widget_hide(jourrmalek);

moispmalek= lookup_widget(calendrier,"moispmalek");
gtk_widget_hide(moispmalek);

moisrmalek= lookup_widget(calendrier,"moisrmalek");
gtk_widget_hide(moisrmalek);

anneepmalek= lookup_widget(calendrier,"anneepmalek");
gtk_widget_hide(anneepmalek);

annermalek= lookup_widget(calendrier,"annermalek");
gtk_widget_hide(annermalek);

qtemalek= lookup_widget(calendrier,"qtemalek");
gtk_widget_hide(qtemalek);

label1= lookup_widget(calendrier,"label7");
gtk_widget_hide(label1);

label2= lookup_widget(calendrier,"label8");
gtk_widget_hide(label2);

label3= lookup_widget(calendrier,"label19");
gtk_widget_hide(label3);
valider_modif_malek= lookup_widget(calendrier,"valider_modif_malek");
gtk_widget_hide(valider_modif_malek);
gtk_widget_show(calendrier);

treeview_cal=lookup_widget(calendrier,"treeview_cal");
afficher_plante(treeview_cal);

}


void
on_anneesmalek_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_pdispomalek_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *accueil;
GtkWidget *produitdispomalek;
GtkWidget *affichemalek;

accueil= lookup_widget(button,"accueilmalek");
gtk_widget_destroy(accueil);

produitdispomalek=lookup_widget(button,"produitdispomalek");
produitdispomalek=create_produitdispomalek();
gtk_widget_show(produitdispomalek);
affichemalek=lookup_widget(produitdispomalek,"affichemalek");
afficher_plante(affichemalek);
//anneeseche();
}


void
on_paccueil_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_modifpval_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *idmodifmalek,*nomplantemalek, *jourpmalek, *moispmalek, *anneepmalek, *jourrmalek, *moisrmalek, *annermalek, *qtemalek; 
GtkWidget *supprimerplantmalek;
GtkWidget *calendrier;
GtkWidget *modifierplantmalek, *modifpmalek, *entrytest;
GtkWidget *ajouterplantmalek,*valider_modif_malek, *treeview_cal ;
int id;
FILE *f;
plante h,p;
FILE *i;
int test;
i=fopen("inter.txt","w+");
f=fopen("plante.txt","r");
idmodifmalek= lookup_widget(button,"idmodifmalek"); 
id=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(idmodifmalek));
while(fscanf(f,"%d %s %d %s %d %d %s %d %d\n",&h.id,h.nom,&h.plantation.jour,h.plantation.mois,&h.plantation.annee,&h.recolte.jour,h.recolte.mois,&h.recolte.annee,&h.qte)!=EOF){
if( id==h.id)
fprintf(i,"%d %s %d %s %d %d %s %d %d\n",h.id,h.nom,h.plantation.jour,h.plantation.mois,h.plantation.annee,h.recolte.jour,h.recolte.mois,h.recolte.annee,h.qte);}
fclose(f);

calendrier=lookup_widget(button,"calendrierpmalek");
calendrier=create_calendrierpmalek();
ajouterplantmalek= lookup_widget(calendrier,"ajouterplantmalek");
supprimerplantmalek= lookup_widget(calendrier,"supprimerplantmalek");
modifierplantmalek= lookup_widget(calendrier,"modifierplantmalek");
valider_modif_malek=lookup_widget(calendrier,"valider_modif_malek");

gtk_widget_hide(ajouterplantmalek);
gtk_widget_hide(modifierplantmalek);
gtk_widget_hide(supprimerplantmalek);
gtk_widget_hide(valider_modif_malek);


nomplantemalek=lookup_widget(calendrier,"nomplantemalek");
jourpmalek=lookup_widget(calendrier,"jourpmalek");
moispmalek=lookup_widget(calendrier,"moispmalek");
anneepmalek=lookup_widget(calendrier,"anneepmalek");
jourrmalek=lookup_widget(calendrier,"jourrmalek");
moisrmalek=lookup_widget(calendrier,"moisrmalek");
annermalek=lookup_widget(calendrier,"annermalek");
qtemalek=lookup_widget(calendrier,"qtemalek");
modifpmalek= lookup_widget(button,"modifpmalek"); 
treeview_cal=lookup_widget(calendrier,"treeview_cal");
gtk_widget_hide(treeview_cal);
gtk_widget_destroy(modifpmalek);
gtk_widget_show(calendrier);




fclose(i);
}


void
on_precmodifpmalek_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *modifpmalek;
GtkWidget *calendrier;


modifpmalek= lookup_widget(button,"modifpmalek"); //accueil pointe vers la fenetre accueilmalek
gtk_widget_destroy(modifpmalek);

calendrier=lookup_widget(button,"calendrierpmalek");//calendrier pointe vers la fenetre calendrierpmalek
calendrier=create_calendrierpmalek();
gtk_widget_show(calendrier);

}


void
on_precsuppmalek_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *supprimerpmalek;
GtkWidget *calendrier;

calendrier=lookup_widget(button,"calendrierpmalek");
supprimerpmalek= lookup_widget(button,"supprimerpmalek"); 
gtk_widget_destroy(supprimerpmalek);
calendrier=create_calendrierpmalek();
gtk_widget_show(calendrier);

}


void
on_validersuppmalek_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *supprimerpmalek;
GtkWidget *calendrier;
GtkWidget *id_supp_malek;
int id;

id_supp_malek=lookup_widget(button,"id_supp_malek");
calendrier=lookup_widget(button,"calendrierpmalek");
supprimerpmalek= lookup_widget(button,"supprimerpmalek"); 

id=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(id_supp_malek));
gtk_widget_destroy(supprimerpmalek);
calendrier=create_acceuil();
gtk_widget_show(calendrier);

supprimer_plante(id);
}


void
on_valider_modif_malek_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *nomplantmalek, *jourpmalek, *moispmalek, *anneepmalek, *jourrmalek, *moisrmalek, *annermalek, *qtemalek; //declaration des variables qui vont pointer vers les entrées : combobox spinbuttons
FILE *f; //f est un fichier
GtkWidget *accueil;
GtkWidget *calendrier;
plante p;

nomplantmalek=lookup_widget(button,"nomplantemalek"); // ces lignes sont pour l'affectation des ponteurs pour les input dans la fenetre
jourpmalek=lookup_widget(button,"jourpmalek");
moispmalek=lookup_widget(button,"moispmalek");
anneepmalek=lookup_widget(button,"anneepmalek");
jourrmalek=lookup_widget(button,"jourrmalek");
moisrmalek=lookup_widget(button,"moisrmalek");
annermalek=lookup_widget(button,"annermalek");
qtemalek=lookup_widget(button,"qtemalek");

strcpy(p.nom,gtk_combo_box_get_active_text(GTK_COMBO_BOX(nomplantmalek))); // pour lire le contenue du combobox
p.plantation.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jourpmalek));  	// pour lire le contenue du spinbutton
strcpy(p.plantation.mois,gtk_combo_box_get_active_text(GTK_COMBO_BOX(moispmalek)));
p.plantation.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(anneepmalek));
p.recolte.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jourrmalek));
strcpy(p.recolte.mois,gtk_combo_box_get_active_text(GTK_COMBO_BOX(moisrmalek)));
p.recolte.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annermalek));
p.qte=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(qtemalek));

ajouter_plante(p);


calendrier=lookup_widget(button,"calendrierpmalek");//calendrier pointe vers la fenetre calendrierpmalek
accueil= lookup_widget(button,"accueilmalek"); //accueil pointe vers la fenetre accueilmalek
gtk_widget_destroy(calendrier);
accueil=create_acceuil();
gtk_widget_show(accueil);
}


void
on_ok_modif_m_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *nomplantmalek, *jourpmalek, *moispmalek, *anneepmalek, *jourrmalek, *moisrmalek, *annermalek, *qtemalek; //declaration des variables qui vont pointer vers les entrées : combobox spinbuttons

GtkWidget *accueilmalek;
GtkWidget *calendrierpmalek;
plante p,h;
FILE *i;
i=fopen("inter.txt","r");

fscanf(i,"%d %s %d %s %d %d %s %d %d\n",&h.id,h.nom,&h.plantation.jour,h.plantation.mois,&h.plantation.annee,&h.recolte.jour,h.recolte.mois,&h.recolte.annee,&h.qte);


nomplantmalek=lookup_widget(button,"nomplantemalek"); // ces lignes sont pour l'affectation des ponteurs pour les input dans la fenetre
jourpmalek=lookup_widget(button,"jourpmalek");
moispmalek=lookup_widget(button,"moispmalek");
anneepmalek=lookup_widget(button,"anneepmalek");
jourrmalek=lookup_widget(button,"jourrmalek");
moisrmalek=lookup_widget(button,"moisrmalek");
annermalek=lookup_widget(button,"annermalek");
qtemalek=lookup_widget(button,"qtemalek");

strcpy(p.nom,gtk_combo_box_get_active_text(GTK_COMBO_BOX(nomplantmalek))); // pour lire le contenue du combobox
p.plantation.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jourpmalek));  	// pour lire le contenue du spinbutton
strcpy(p.plantation.mois,gtk_combo_box_get_active_text(GTK_COMBO_BOX(moispmalek)));
p.plantation.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(anneepmalek));
p.recolte.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jourrmalek));
strcpy(p.recolte.mois,gtk_combo_box_get_active_text(GTK_COMBO_BOX(moisrmalek)));
p.recolte.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annermalek));
p.qte=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(qtemalek));
supprimer_plante(h.id);
p.id=h.id;
ajouter_plante(p);
fclose(i);

accueilmalek= lookup_widget(button,"accueilmalek");
accueilmalek=create_acceuil();
gtk_widget_show(accueilmalek);

calendrierpmalek= lookup_widget(button,"calendrierpmalek");
gtk_widget_destroy(calendrierpmalek);

}


void
on_pas_acc_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *accueil;
GtkWidget *produitdispomalek;

produitdispomalek=lookup_widget(button,"produitdispomalek");
accueil= lookup_widget(button,"accueilmalek"); 
gtk_widget_destroy(produitdispomalek);
accueil=create_acceuil();
gtk_widget_show(accueil);
}



void
on_conf_clicked                        (GtkButton       *button,
                                        gpointer         user_data)
{
char nom[30] , mdp[30] , role [30];
GtkWidget *existe, *entrynom , *entrymdp , *entryrole , *auth;

auth=lookup_widget(button,"auth");
existe=lookup_widget(auth,"ex");
entrynom=lookup_widget(auth,"entrynomf1");
entrymdp=lookup_widget(auth,"entrymdpf1");
entryrole=lookup_widget(auth,"comboboxrolef");
strcpy(nom, gtk_entry_get_text(GTK_ENTRY(entrynom)));
strcpy(mdp, gtk_entry_get_text(GTK_ENTRY(entrymdp)));
strcpy(role,gtk_combo_box_get_active_text(GTK_COMBO_BOX(entryrole)));
if (strcmp(nom,"user")==0 && strcmp(mdp,"user")==0 && strcmp(role,"administrateur")==0){
admin=create_admin();
gtk_widget_destroy(auth);
gtk_widget_show(admin);}
else { if  ( verifierutilisateur(nom,mdp) == 1 &&  strcmp(role,"utilisateur")==0 ){
acceuil=create_acceuil();

gtk_widget_destroy(auth);

gtk_widget_show(acceuil);}

else {gtk_widget_show(existe);}

}

}

void
on_gut_clicked                         (GtkButton       *button,
                                        gpointer         user_data)
{
gutilisateurs=create_gutilisateurs();
gtk_widget_destroy(admin);
gtk_widget_show(gutilisateurs);
}


void
on_tdbf_clicked                        (GtkButton       *button,
                                        gpointer         user_data)
{
acceuil=create_acceuil();
gtk_widget_destroy(admin);
gtk_widget_show(acceuil);
}


void
on_decof_clicked                       (GtkButton       *button,
                                        gpointer         user_data)
{
auth=create_auth();
gtk_widget_destroy(admin);
gtk_widget_show(auth);
}


void
on_ajouterf_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *existe , *success , *erreur , *entrynom , *entrymdp ;
char nom[30] , mdp [30];
//label
existe=lookup_widget(gutilisateurs,"existef");
success=lookup_widget(gutilisateurs,"successf");
erreur=lookup_widget(gutilisateurs,"veriff");
//entries
entrynom=lookup_widget(gutilisateurs,"entrynomf");
entrymdp=lookup_widget(gutilisateurs,"entrymdpf");

strcpy(nom, gtk_entry_get_text(GTK_ENTRY(entrynom)));
if(strcmp(nom,"")==0){
gtk_widget_show(erreur);

}
else
{
gtk_widget_set_visible(erreur,FALSE);

}
strcpy(mdp, gtk_entry_get_text(GTK_ENTRY(entrymdp)));
if(strcmp(mdp,"")==0){
gtk_widget_show(erreur);

}
else
{
gtk_widget_set_visible(erreur,FALSE);

}
if(gtk_widget_get_visible(erreur)==FALSE ){
	if(verifierutilisateur(nom,mdp)==1){
	gtk_widget_set_visible(success,FALSE);
	gtk_widget_show(existe);
	}	
	else{
	ajouterutilisateur(nom,mdp);
	
	//bien ajouté 
	gtk_widget_set_visible(existe,FALSE);
	gtk_widget_show(success);
	//vider les champs après ajout
	gtk_entry_set_text(GTK_ENTRY(entrynom),"");
	gtk_entry_set_text(GTK_ENTRY(entrymdp),"");
	
	}
}
}

void
on_quitterf_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
admin=create_admin();

gtk_widget_destroy(gutilisateurs);
gtk_widget_show(admin);
}

