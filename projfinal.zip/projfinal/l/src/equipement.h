#include <gtk/gtk.h>
void ajouter_equipement(equipement e );

int exist_equipement(char*reference);
void supprimer_equipement(char*reference);
void modifier_equipement(equipement e);

