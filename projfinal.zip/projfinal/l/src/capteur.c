#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <gtk/gtk.h>
#include "capteur.h"

enum
{
  NOM,
  ID,
  TYPE,
  MARK,
  DATE,
  PRIX,
  
  COLUMNS
};

int ajouter_capteur (capteur c)
{

FILE* f;
capteur x;
int test;
f=fopen("capteur.txt","a");
  if(f!=NULL)
   {while (fscanf(f,"%s %s %s %s %s %s \n",x.nom,x.id,x.mark,x.type,x.prix,x.date)!=EOF)
 {


   
        if(strcmp(x.id,c.id)==0)
            {
 		test=1;
                 return 1 ;
	    }
}
}
  if (test==0)
{
  fprintf(f,"%s %s %s %s %s %s  \n",c.nom,c.id,c.mark,c.type,c.prix,c.date);
  fclose(f);
 return 0;
}

}
int modifier_capteur(capteur c)
{

capteur x;

FILE *f;
FILE *f2;
f=fopen("capteur.txt","r");
f2=fopen("capteur_tmp.txt","a+"); 
if (f!=NULL)
{
if (f2!=NULL)

{ 
     while (fscanf(f,"%s %s %s %s %s %s \n",x.nom,x.id,x.type,x.mark,x.date,x.prix)!=EOF)
    { 
	if (strcmp(c.id,x.id)==0){
   fprintf(f2,"%s %s %s %s %s %s  \n",c.nom,c.id,c.mark,c.type,c.prix,c.date);
}
	else 	
{	    fprintf(f2,"%s %s %s %s %s %s \n",x.nom,x.id,x.type,x.mark,x.date,x.prix);
     }

}}
fclose(f2);
fclose(f);
remove("capteur.txt");
rename("capteur_tmp.txt","capteur.txt");

}

}

int supprimer_capteur(char refer[])
{

FILE *f,*f1;
capteur c;
 
f=fopen("capteur.txt","r"); 
f1=fopen("capteur_tmp.txt","w");
 if ((f!=NULL) && (f1!=NULL))
{
while(fscanf(f,"%s %s %s %s %s %s \n",c.nom,c.id,c.type,c.mark,c.date,c.prix)!=EOF) 
{
if(strcmp(refer,c.id)!=0)
{
fprintf(f1,"%s %s %s %s %s %s \n",c.nom,c.id,c.type,c.mark,c.date,c.prix);
}}
fclose(f) ; 
fclose(f1);}
 
f=fopen("capteur.txt","w"); 
f1=fopen("capteur_tmp.txt","r");
if ((f!=NULL) && (f1!=NULL))
{
while(fscanf(f1,"%s %s %s %s %s %s \n",c.nom,c.id,c.type,c.mark,c.date,c.prix)!=EOF) 
{
if(strcmp(refer,c.id)!=0)
{
fprintf(f,"%s %s %s %s %s %s\n",c.nom,c.id,c.type,c.mark,c.date,c.prix);
}}
fclose(f) ; 
fclose(f1);
}
 
}
int recherche_capteur (char id[])
{ 
   int test;
   capteur x;
FILE *f;
  f=fopen("capteur.txt","r");
   test=1;
   if (f!=NULL)
{ 
    while(fscanf(f,"%s %s %s %s %s %s \n",x.nom,x.id,x.type,x.mark,x.date,x.prix)!=EOF)
{
             if(strcmp(id,x.id)==0)
{    
                 test=0;
                 break;
                 
              
}
}
}
if (test==0)
{
  return 0;
}
else
{ return 1;
}
}
void afficher_capteur (GtkWidget *liste)
{
        GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;
	
	
	char nom[100];
	char id[100];
	char type[100];
	char mark[100];
	char date[100];
	char prix[100];
	FILE*f;
        store=NULL;
	
	
	store=gtk_tree_view_get_model(liste);	
	if (store==NULL)
	{

			
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("nom", renderer, "text",NOM, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("id", renderer, "text",ID, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

 		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("mark", renderer, "text",MARK, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);	
		
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("type", renderer, "text",TYPE, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);	
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("prix", renderer, "text",PRIX, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
              
                renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("date", renderer, "text",DATE, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
             
                
	}
		
                store=gtk_list_store_new (COLUMNS,G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

	f = fopen("capteur.txt","r");
	
	if(f ==NULL)
	{

		return;
	}		
	else

	{
		f=fopen("capteur.txt","a+");
	
		while(fscanf(f,"%s %s %s  %s %s %s\n",nom,id,mark,type,prix,date)!=EOF)
		{
		gtk_list_store_append (store, &iter);
		gtk_list_store_set (store,&iter,NOM,nom,ID,id,MARK,mark,TYPE,type,PRIX,prix,DATE,date,-1);
		}
		
		fclose(f);}
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);
       
}	

