void Affichertroupeaux(GtkWidget* liste);
int Cherchertroupeaux(GtkWidget* liste,char*l,char*nm);
