#include <gtk/gtk.h>
typedef struct{
int j;
int m;
int a;
}Date;

typedef struct{
char identifiant[30];
char type[30];
char sexe[30];
char etat [30]; 
Date date;
}Troupeau;

void ajouter_troupeaux(Troupeau t );

int exist_troupeaux(char*identifiant);
void supprimer_troupeaux(char*identifiant);
void modifier_troupeaux(Troupeau t );
