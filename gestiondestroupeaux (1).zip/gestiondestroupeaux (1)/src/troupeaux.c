#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include "callbacks.h"
#include "troupeaux.h"
#include<string.h>

void ajouter_troupeaux(Troupeau t )
{
FILE*f=NULL;
f=fopen("troupeaux.txt","a+");
fprintf(f,"%s %s %s %s %d %d %d \n",t.identifiant,t.type,t.sexe,t.etat,t.date.j,t.date.m,t.date.a);  
fclose(f); 
}
//*******************************************//
int exist_troupeaux(char*identifiant){
FILE*f=NULL;
 Troupeau t;
f=fopen("troupeaux.txt","r");
while(fscanf(f,"%s %s %s %s %d %d %d \n",t.identifiant,t.type,t.sexe,t.etat,&t.date.j,&t.date.m,&t.date.a)!=EOF){
if(strcmp(t.identifiant,identifiant)==0)
return 1;
}
fclose(f);
return 0;
}
//**********************************//
void supprimer_troupeaux(char*identifiant){
FILE*f=NULL;
FILE*f1=NULL;
Troupeau t ;
f=fopen("troupeaux.txt","r");
f1=fopen("ancien.txt","w+");//mode lecture et ecriture 
while(fscanf(f,"%s %s %s %s %d %d %d \n",t.identifiant,t.type,t.sexe,t.etat,&t.date.j,&t.date.m,&t.date.a)!=EOF){
if(strcmp(identifiant,t.identifiant)!=0)fprintf(f1,"%s %s %s %s %d %d %d \n",t.identifiant,t.type,t.sexe,t.etat,t.date.j,t.date.m,t.date.a);
}
fclose(f);
fclose(f1);
remove("troupeaux.txt");
rename("ancien.txt","troupeaux.txt");
}
//**********************************//

void modifier_troupeaux(Troupeau t ){
FILE*f=NULL;
FILE*f1=NULL;
Troupeau tr;
f=fopen("troupeaux.txt","r");
f1=fopen("ancien.txt","w+");
while(fscanf(f,"%s %s %s %s %d %d %d \n",tr.identifiant,tr.type,tr.sexe,tr.etat,&tr.date.j,&tr.date.m,&tr.date.a)!=EOF){
if( strcmp(t.identifiant,tr.identifiant)==0)
{
fprintf(f1,"%s %s %s %s %d %d %d  \n",t.identifiant,t.type,t.sexe,t.etat,t.date.j,t.date.m,t.date.a);
}
else
{
fprintf(f1,"%s %s %s %s %d %d %d \n",tr.identifiant,tr.type,tr.sexe,tr.etat,tr.date.j,tr.date.m,tr.date.a);
}

}
fclose(f);
fclose(f1);
remove("troupeaux.txt");
rename("ancien.txt","troupeaux.txt");
}




