#include <gtk/gtk.h>
void
on_acceuilGestion_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeajou_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_bmodifier_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_bsupprimer_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_bafficher12_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeretourr_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button19_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_QuitAjouter_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_RetourAffich_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_MaladeModif_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_Bonsant__Modif_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton1ajout_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ModifAffich_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_Modifiertrou_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_Malade_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Bonsant___toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_trouAfficher_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_AjouterTroupeaux_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_Bonsant__Modif_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_MaladeModif_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button22_quit_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button24_retourM_clicked            (GtkButton       *button,
                                        gpointer         user_data);
