#include <stdlib.h>
#include <stdio.h>
#include<string.h>
#include <gtk/gtk.h>
#include "interface.h"
#include "callbacks.h"
#include "treeview.h"
#include "troupeaux.h"
enum
{
	EIDENTIFIANT,
	ETYPE,
	ESEXE,
	EETAT,
	J,
	M,
	A,
	COLUMNS,
};
GtkListStore *adstore;/*creation du modele de type liste*/
GtkTreeViewColumn *adcolumn;/*visualisation des colonnes*/
GtkCellRenderer *cellad;/*afficheur de cellule(text,image..)*/
FILE *f;
void Affichertroupeaux(GtkWidget* liste){

GtkCellRenderer *renderer;
	    GtkTreeViewColumn *column;
 	    GtkTreeIter iter;
	    GtkListStore *store;
	    Troupeau t;
	char identifiant[30];
	char type[30];
	char sexe[30];
	char etat [30]; 
	int j;
	int m;
	int a;

	
	    store==NULL;
 	    
	    FILE *f;
	    
	    store=gtk_tree_view_get_model(liste);
	    if(store==NULL)
            {
            renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Identifiant",renderer ,"text",EIDENTIFIANT, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Type",renderer ,"text",ETYPE, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Sexe",renderer ,"text",ESEXE, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Etat",renderer ,"text",EETAT, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	   
	
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Jour",renderer ,"text",J, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Mois",renderer ,"text",M, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Annee",renderer ,"text",A, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	    }
	    store=gtk_list_store_new (COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,  G_TYPE_INT,G_TYPE_INT,G_TYPE_INT);

	    f=fopen("troupeaux.txt","r");
	    if(f==NULL)
	    {
	          return;
	    }

	    else
	    {  
			f=fopen("troupeaux.txt","a+");
			while(fscanf(f,"%s %s %s %s %d %d %d \n",identifiant,type,sexe,etat,&j,&m,&a)!=EOF)
			{
				gtk_list_store_append (store, &iter);
				gtk_list_store_set (store, &iter, EIDENTIFIANT, identifiant, ETYPE, type, ESEXE, sexe, EETAT,etat,J,j,M,m,A,a, -1);
			}
			fclose(f);
			gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
			g_object_unref (store);
	    }

}
//******************************************//

int Cherchertroupeaux(GtkWidget* liste,char*l,char*nm){
GtkCellRenderer *renderer;
	    GtkTreeViewColumn *column;
 	    GtkTreeIter iter;
	    GtkListStore *store;
	    Troupeau t;
	char identifiant[30];
	char type[30];
	char sexe[30];
	char etat [30];
	int j;
	int m;
	int a;
	int nb=0;
	    store==NULL;
 	    
	    FILE *f;
	    
	    store=gtk_tree_view_get_model(liste);
	    if(store==NULL)
            {
            renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Identifiant",renderer ,"text",EIDENTIFIANT, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Type",renderer ,"text",ETYPE, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Sexe",renderer ,"text",ESEXE, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	    
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Etat",renderer ,"text",EETAT, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	   
	
	    renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Jour",renderer ,"text",J, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Mois",renderer ,"text",M, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	    column = gtk_tree_view_column_new_with_attributes("Annee",renderer ,"text",A, NULL);
	    gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	    }
	    store=gtk_list_store_new (COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,  G_TYPE_INT,G_TYPE_INT,G_TYPE_INT);

	    f=fopen(l,"r");
	    if(f==NULL)
	    {
	          return;
	    }

	    else
	    {  
			f=fopen(l,"a+");
			while(fscanf(f,"%s %s %s %s %d %d %d \n",identifiant,type,sexe,etat,&j,&m,&a)!=EOF)
			{ if (strcmp(nm,identifiant)==0){ nb++;
				gtk_list_store_append (store, &iter);
				gtk_list_store_set (store, &iter, EIDENTIFIANT, identifiant, ETYPE, type, ESEXE, sexe, EETAT,etat,J,j,M,m,A,a, -1);
			}}
			fclose(f);
			gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
			g_object_unref (store);
	    }
return nb;
}






