#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "treeview.h"
#include "troupeaux.h"

GtkWidget *acceuil;
GtkWidget *gestion;
GtkWidget *window1;
GtkWidget *window2;

GtkTreeSelection *selection1;

int btnradiomodif=0;
int btnradioajou=0;
int validajou=0;
int validmodif=0;
int btnradiointerface=0;
void
on_acceuilGestion_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *p;
gtk_widget_hide (acceuil);
window1=create_window1();
gtk_widget_show (window1);
p=lookup_widget(window1,"treeview2");
Affichertroupeaux(p);



}



void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
    gchar *identifiant;
    gchar *type;
    gchar *sexe;
    gchar *etat;
    gint *j;
    gint *m;
    gint *a;
        GtkTreeModel     *model;
        GtkTreeIter iter;
        GtkWidget *p=lookup_widget(window1,"treeview2");
        selection1 = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));

}


void
on_treeajou_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
gestion = create_gestion ();
gtk_widget_show (gestion);
gtk_widget_hide (window1);
}


void
on_bmodifier_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
 char *identifiant;
    char *type;
    char *sexe;
   char *etat;
    int j;
    int m;
    int a;
window2=create_window2();
        GtkTreeModel     *model;
GtkWidget     *labelvalid;

        GtkTreeIter iter;
        if (gtk_tree_selection_get_selected(selection1, &model, &iter))
        {

        gtk_widget_hide(lookup_widget(window2,"label52"));//cacher label modifier avec succees
gtk_widget_hide(lookup_widget(window2,"label48"));
                gtk_tree_model_get (model,&iter,0,&identifiant, 1, &type, 2, &sexe,3,&etat,4,&j,5,&m,6,&a,-1);
           gtk_label_set_text(GTK_ENTRY(lookup_widget(window2,"label54")),identifiant);
 //gtk_entry_set_text(GTK_ENTRY(lookup_widget(window2,"modifReference")),reference);
if (strcmp(type,"Veau")==0){
gtk_combo_box_set_active (GTK_COMBO_BOX(lookup_widget(window2,"combobox3")),2 );
}
else if (strcmp(type,"Brebi")==0){
gtk_combo_box_set_active (GTK_COMBO_BOX(lookup_widget(window2,"combobox3")),1 );}

if (strcmp(sexe,"Femelle")==0){
gtk_combo_box_set_active (GTK_COMBO_BOX(lookup_widget(window2,"combobox4")),2 );
}
else if (strcmp(sexe,"Mâle")==0){
gtk_combo_box_set_active (GTK_COMBO_BOX(lookup_widget(window2,"combobox4")),1 );}

gtk_spin_button_set_value(GTK_SPIN_BUTTON(lookup_widget(window2,"spinbutton5")),j);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(lookup_widget(window2,"spinbutton4")),m);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(lookup_widget(window2,"spinbutton6")),a);

if (strcmp(etat,"Malade")==0){
gtk_toggle_button_set_active(GTK_RADIO_BUTTON (lookup_widget(window2,"MaladeModif")),TRUE);
}
else if (strcmp(etat,"BonSanté")==0){
gtk_toggle_button_set_active(GTK_RADIO_BUTTON (lookup_widget(window2,"BonsantéModif")),TRUE);
}
gtk_widget_show (window2);
gtk_widget_hide (window1);
  }

}



void
on_bsupprimer_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
{
    gchar *identifiant;
    gchar *type;
    gchar *sexe;
    gchar *etat;
    gint *j;
    gint *m;
    gint *a;
    GtkTreeModel     *model;
    GtkTreeIter iter;
       if (gtk_tree_selection_get_selected(selection1, &model, &iter))
        {
            gtk_tree_model_get (model,&iter,0,&identifiant, 1, &type, 2, &sexe,3,&etat,4,&j,5,&m,6,&a,-1);//recuperer les information de la ligne selectionneé
            supprimer_troupeaux(identifiant);
            Affichertroupeaux(lookup_widget(window1,"treeview2"));        
        }
}

}


void
on_bafficher12_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *nbResultat;
GtkWidget *message;
nbResultat=lookup_widget(window1,"label27");
message=lookup_widget(window1,"label3");

Affichertroupeaux(lookup_widget(window1,"treeview2"));
gtk_widget_hide (nbResultat);
gtk_widget_hide (message);

}


void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *p1;
GtkWidget *entry;
GtkWidget *labelidentifiant;
GtkWidget *nbResultat;
GtkWidget *message;
char identifiant[30];
char chnb[30];
int b=0,nb;
entry=lookup_widget(window1,"entry10");
labelidentifiant=lookup_widget(window1,"label28");
p1=lookup_widget(window1,"treeview2");
strcpy(identifiant,gtk_entry_get_text(GTK_ENTRY(entry)));

if(strcmp(identifiant,"")==0){
  gtk_widget_show (labelidentifiant);b=0;
}else{
b=1;
gtk_widget_hide (labelidentifiant);}

if(b==0)
    {return;
    }
    else
    {

nb=Cherchertroupeaux(p1,"troupeaux.txt",identifiant);
// afficher le nombre de resultats obtenue par la recherche */

sprintf(chnb,"%d",nb);        //conversion int==> chaine car la fonction gtk_label_set_text naccepte que chaine
nbResultat=lookup_widget(window1,"label27");
message=lookup_widget(window1,"label3");
gtk_label_set_text(GTK_LABEL(nbResultat),chnb);

gtk_widget_show (nbResultat);
gtk_widget_show (message);
}

}
void
on_treeretourr_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_show (acceuil);
gtk_widget_hide (window1);
}


void
on_button19_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_show (acceuil);
gtk_widget_hide (window1);
}


void
on_QuitAjouter_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_show (window1);
gtk_widget_hide (gestion);
}


void
on_RetourAffich_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_show (window1);
gtk_widget_hide (gestion);
}


void
on_MaladeModif_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_Bonsant__Modif_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_checkbutton1ajout_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_CHECK_BUTTON (togglebutton)))
{validajou=1;}
else
{validajou=0;}
}



void
on_ModifAffich_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_show (window1);
gtk_widget_hide (window2);
Affichertroupeaux(lookup_widget(window1,"treeview2"));
}


void
on_Modifiertrou_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

Troupeau t ;
       	 GtkWidget *entryidentifiant, *entrtype, *entrysexe, *entryetat, *entryj, *entrym, *entrya, *labelvalid,*success;

entryidentifiant=lookup_widget(window2,"label54");
entrtype=lookup_widget(window2,"combobox3");
entrysexe=lookup_widget(window2,"combobox4");
entryj=lookup_widget(window2,"spinbutton5");
entrym=lookup_widget(window2,"spinbutton4");
entrya=lookup_widget(window2,"spinbutton6");
labelvalid=lookup_widget(window2,"label48");
success=lookup_widget(window2,"label52");
 strcpy(t.identifiant,gtk_label_get_text(GTK_LABEL(entryidentifiant) ) );
 strcpy(t.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(entrtype) ) );
 strcpy(t.sexe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(entrysexe) ) );

t.date.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entryj));
t.date.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entrym));
t.date.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entrya));
if (btnradiomodif==2){
strcpy(t.etat,"BonSanté");}
else if (btnradiomodif==1){
strcpy(t.etat,"Malade");}
gtk_widget_show(labelvalid);
gtk_widget_hide(success);
if (validmodif==1)
{
     

gtk_widget_hide(labelvalid);
gtk_widget_show(success);

        modifier_troupeaux(t);
}
}

void
on_Malade_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{btnradioajou=1;}
}


void
on_Bonsant___toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{btnradioajou=2;}
}



void
on_trouAfficher_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
window1=create_window1();
gtk_widget_show (window1);
gtk_widget_hide (gestion);
Affichertroupeaux(lookup_widget(window1,"treeview2")); 
}


void
on_AjouterTroupeaux_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
Troupeau t;

GtkWidget *entryidentifiant, *entrtype, *entrysexe, *entryetat, *entryj, *entrym, *entrya; 
GtkWidget *labelidentifiant;
GtkWidget *labeltype;
GtkWidget *labelsexe;
GtkWidget *labelvalid;

GtkWidget *existe;
GtkWidget* success;
int b=1;

entryidentifiant=lookup_widget(button,"entry11");
entrtype=lookup_widget(button,"combobox1");
entrysexe=lookup_widget(button,"combobox2");
entryj=lookup_widget(button,"spinbutton1");
entrym=lookup_widget(button,"spinbutton2");
entrya=lookup_widget(button,"spinbutton3");


labelidentifiant=lookup_widget(button,"label36");
labeltype=lookup_widget(button,"label37");
labelsexe=lookup_widget(button,"label38");
labelvalid=lookup_widget(button,"label39");
existe=lookup_widget(button,"label34");
success=lookup_widget(button,"label35");

strcpy(t.identifiant,gtk_entry_get_text(GTK_ENTRY(entryidentifiant)));
strcpy(t.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(entrtype) ) );
strcpy(t.sexe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(entrysexe) ) );

t.date.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entryj));

t.date.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entrym));

t.date.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(entrya));

if (btnradioajou==2){
strcpy(t.etat,"BonSanté");}
else if (btnradioajou==1){
strcpy(t.etat,"Malade");}
gtk_widget_hide(success);

if(strcmp(t.identifiant,"")==0){
		  gtk_widget_show (labelidentifiant);
b=0;
}
else {
		  gtk_widget_hide(labelidentifiant);
}

if(strcmp(t.type,"...")==0){
		  gtk_widget_show (labeltype);
b=0;
}
else {
		  gtk_widget_hide(labeltype);
}
if(strcmp(t.sexe,"...")==0){
		  gtk_widget_show (labelsexe);
b=0;
}
else {
		  gtk_widget_hide(labelsexe);
}

gtk_widget_show(labelvalid);
if (validajou==1)
{gtk_widget_hide(labelvalid);
if(b==1)
{

        if(exist_troupeaux(t.identifiant)==1)
        {

				  gtk_widget_show (existe);
        }
        else {
						  gtk_widget_hide (existe);
               

						  gtk_widget_show (success);

        ajouter_troupeaux(t); }

        

						
        }}

 }


void
on_Bonsant__Modif_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{btnradiomodif=2;}
}


void
on_MaladeModif_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{btnradiomodif=1;}
}


void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if ( gtk_toggle_button_get_active(GTK_CHECK_BUTTON (togglebutton)))
{validmodif=1;}
else
{validmodif=0;}
}
void
on_button22_quit_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_show (window1);
gtk_widget_hide (window2);
}
void
on_button24_retourM_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_show (window1);
gtk_widget_hide (window2);
}

