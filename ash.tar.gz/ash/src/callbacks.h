#include <gtk/gtk.h>


void
on_button_ajoute_cap_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_annul_ajt_cap_clicked        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_rech_mod_cap_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_modif_cap_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_annul_modif_cap_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_affich_cap_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_rech_sup_cap_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_sup_cap_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button10_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button9_clicked                     (GtkButton      *objet_graphique,
                                        gpointer         user_data);

void
on_button11_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button12_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button13_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button14_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data);
