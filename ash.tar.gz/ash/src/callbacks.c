#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "capteur.h"


void
on_button_ajoute_cap_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
int a;
           capteur c;
        GtkWidget *input1,*input2,*input3,*combobox1,*input5,*input6;
        GtkWidget *output1;
        
        input1=lookup_widget(objet_graphique,"entry1");
        input2=lookup_widget(objet_graphique,"entry2");
        input3=lookup_widget(objet_graphique,"entry4");
	combobox1=lookup_widget(objet_graphique,"combobox1");
        input5=lookup_widget(objet_graphique,"entry3");
        input6=lookup_widget(objet_graphique,"entry10");
        output1=lookup_widget(objet_graphique,"label5");
	
        strcpy(c.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
        strcpy(c.id,gtk_entry_get_text(GTK_ENTRY(input2)));
        strcpy(c.mark,gtk_entry_get_text(GTK_ENTRY(input3)));
        strcpy(c.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
	strcpy(c.prix,gtk_entry_get_text(GTK_ENTRY(input5)));
	strcpy(c.date,gtk_entry_get_text(GTK_ENTRY(input6)));
	
        
        
	
        if ((strlen(c.id)==0)||(strlen(c.mark)==0)||(strlen(c.prix)==0) || (strlen(c.nom)==0) ||(strlen(c.date)==0) )
{

       gtk_label_set_text(GTK_LABEL(output1),"veuilez remplir toutes les cases");
}
else
{
        a=ajouter_capteur(c);
        if (a==0){
       
        gtk_label_set_text(GTK_LABEL(output1),"ajout avec succés");
       }
       else  
      {
       gtk_label_set_text(GTK_LABEL(output1),"membre deja existant");
       }
}

}


void
on_button_annul_ajt_cap_clicked        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *input1,*input2,*input3,*combobox1,*input5,*input6;
        GtkWidget *output1;
        
        input1=lookup_widget(objet_graphique,"entry1");
        input2=lookup_widget(objet_graphique,"entry2");
        input3=lookup_widget(objet_graphique,"entry3");
	//combobox1=lookup_widget(objet_graphique,"combobox1");
        input5=lookup_widget(objet_graphique,"entry4");
        input6=lookup_widget(objet_graphique,"entry10");


    gtk_entry_set_text(GTK_ENTRY(input1),"");
    gtk_entry_set_text(GTK_ENTRY(input2),"");
    gtk_entry_set_text(GTK_ENTRY(input3),"");
    gtk_entry_set_text(GTK_ENTRY(input5),"");
    gtk_entry_set_text(GTK_ENTRY(input6),"");
    //gtk_combo_box_get_active_text(Gtk_ComboBox(combobox1),"");

}


void
on_button_rech_mod_cap_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	char nom[30];
	char id[30];
	char type[30];
	char mark[30];
	char date[30];
	char prix[30]; 
   int x;
   GtkWidget *input;
   GtkWidget *output;
   input=lookup_widget(objet_graphique,"entry5");
   strcpy(id,gtk_entry_get_text(GTK_ENTRY(input)));
   x=recherche_capteur(id);
   output=lookup_widget(objet_graphique,"label19");
 if ((strlen(id)==0))
{
       gtk_label_set_text(GTK_LABEL(output),"veuilez remplir la case");
}
else 
{
   if (x==1)
{
   gtk_label_set_text(GTK_LABEL(output),"membre non existant");
  
}
else
{
  
  gtk_label_set_text(GTK_LABEL(output),id);
}
}
}


void
on_button_modif_cap_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
capteur c; 
        GtkWidget *input1, *input2,*input3,*combobox1,*input5,*input6;
        GtkWidget *output,*output1,*output2;
        
        input1=lookup_widget(objet_graphique,"entry5");
        input2=lookup_widget(objet_graphique,"entry6");
        input3=lookup_widget(objet_graphique,"entry7");
	combobox1=lookup_widget(objet_graphique,"combobox2");
        input5=lookup_widget(objet_graphique,"entry8");
        input6=lookup_widget(objet_graphique,"entry11");
        output1=lookup_widget(objet_graphique,"label19");
        
        strcpy(c.id,gtk_label_get_text(GTK_LABEL(output1)));
        strcpy(c.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
        strcpy(c.mark,gtk_entry_get_text(GTK_ENTRY(input3)));
        strcpy(c.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
        strcpy(c.prix,gtk_entry_get_text(GTK_ENTRY(input5)));
	strcpy(c.date,gtk_entry_get_text(GTK_ENTRY(input6)));
	
         modifier_capteur(c);
    
    output2=lookup_widget(objet_graphique,"label17"); 
        if ((strlen(c.id)==0)||(strlen(c.mark)==0)||(strlen(c.prix)==0) || (strlen(c.nom)==0) ||(strlen(c.date)==0) )
        
{
       gtk_label_set_text(GTK_LABEL(output2),"veuilez remplir toutes les cases");
}
else
{
     
     
     gtk_label_set_text(GTK_LABEL(output2),"modifié avec succés");
}
}


void
on_button_annul_modif_cap_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *input1,*input2,*input3,*combobox1,*input5,*input6;
        GtkWidget *output1;
        
        input1=lookup_widget(objet_graphique,"entry5");
        input2=lookup_widget(objet_graphique,"entry6");
        input3=lookup_widget(objet_graphique,"entry7");
	//combobox1=lookup_widget(objet_graphique,"combobox1");
        input5=lookup_widget(objet_graphique,"entry8");
        input6=lookup_widget(objet_graphique,"entry11");


    gtk_entry_set_text(GTK_ENTRY(input1),"");
    gtk_entry_set_text(GTK_ENTRY(input2),"");
    gtk_entry_set_text(GTK_ENTRY(input3),"");
    gtk_entry_set_text(GTK_ENTRY(input5),"");
    //gtk_ComboBox_set_text(Gtk_ComboBox(input5),"");

}


void
on_button_affich_cap_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *treeview;
        GtkWidget *window1;
        window1=lookup_widget(objet_graphique,"window3");
        treeview=lookup_widget(objet_graphique,"treeview1");
        
        afficher_capteur(treeview);

}


void
on_button_rech_sup_cap_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
char nom[30];
	char id[30];
	char type[30];
	char mark[30];
	char date[30];
	char prix[30]; 
   int x;
   GtkWidget *input;
   GtkWidget *output;
   input=lookup_widget(objet_graphique,"entry9");
   strcpy(id,gtk_entry_get_text(GTK_ENTRY(input)));
   x=recherche_capteur(id);
   output=lookup_widget(objet_graphique,"label30");
 if ((strlen(id)==0))
{
       gtk_label_set_text(GTK_LABEL(output),"veuilez remplir la case");
}
else 
{
   if (x==1)
{
   gtk_label_set_text(GTK_LABEL(output),"membre non existant");
  
}
else
{
  
  gtk_label_set_text(GTK_LABEL(output),id); 
}
}
}


void
on_button_sup_cap_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	
GtkWidget *input;
GtkWidget *output;
capteur c;
char ref[20];
input=lookup_widget(objet_graphique,"entry9");
output=lookup_widget(objet_graphique,"label28");
strcpy(ref,gtk_entry_get_text(GTK_ENTRY(input)));
if(strcmp(ref,c.id)==0)
gtk_label_set_text(GTK_LABEL(output),"capteur n'existe pas");
else
{
supprimer_capteur(ref);
gtk_label_set_text(GTK_LABEL(output),"suppression avec succée");
}
}


void
on_button10_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1 ;
 GtkWidget *window2;

window1=lookup_widget(objet_graphique,"window3");
gtk_widget_hide(window1);
window2 = create_window1();
gtk_widget_show (window2);
}


void
on_button9_clicked                     (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1 ;
 GtkWidget *window2;

window1=lookup_widget(objet_graphique,"window3");
gtk_widget_hide(window1);
window2 = create_window2();
gtk_widget_show (window2);
}


void
on_button11_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1 ;
 GtkWidget *window2;

window1=lookup_widget(objet_graphique,"window3");
gtk_widget_hide(window1);
window2 = create_window4();
gtk_widget_show (window2);
}


void
on_button12_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *window1 ;
 GtkWidget *window2;

window1=lookup_widget(objet_graphique,"window1");
gtk_widget_hide(window1);
window2 = create_window3();
gtk_widget_show (window2);
}


void
on_button13_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1 ;
 GtkWidget *window2;

window1=lookup_widget(objet_graphique,"window2");
gtk_widget_hide(window1);
window2 = create_window3();
gtk_widget_show (window2);

}


void
on_button14_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1 ;
 GtkWidget *window2;

window1=lookup_widget(objet_graphique,"window4");
gtk_widget_hide(window1);
window2 = create_window3();
gtk_widget_show (window2);
}

