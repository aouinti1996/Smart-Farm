#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include <string.h>
#include <stdlib.h>
#include "plante.h"


void
on_ajouterpmalek_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_chercherpmalek_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_supprimerpmalek_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_ajouterplantmalek_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *calendrier,*treeview_cal;
GtkWidget *valider_modif_malek,*nomplantemalek,*supprimerplantmalek,*modifierplantmalek,*jourpmalek,*jourrmalek,*qtemalek,*moispmalek,*moisrmalek,*anneepmalek,*annermalek,*label1,*label2,*label3;


nomplantemalek= lookup_widget(button,"nomplantemalek");
gtk_widget_show(nomplantemalek);

jourpmalek= lookup_widget(button,"jourpmalek");
gtk_widget_show(jourpmalek);

jourrmalek= lookup_widget(button,"jourrmalek");
gtk_widget_show(jourrmalek);

moispmalek= lookup_widget(button,"moispmalek");
gtk_widget_show(moispmalek);

moisrmalek= lookup_widget(button,"moisrmalek");
gtk_widget_show(moisrmalek);

anneepmalek= lookup_widget(button,"anneepmalek");
gtk_widget_show(anneepmalek);

annermalek= lookup_widget(button,"annermalek");
gtk_widget_show(annermalek);

qtemalek= lookup_widget(button,"qtemalek");
gtk_widget_show(qtemalek);

label1= lookup_widget(button,"label7");
gtk_widget_show(label1);

label2= lookup_widget(button,"label8");
gtk_widget_show(label2);

label3= lookup_widget(button,"label19");
gtk_widget_show(label3);

valider_modif_malek= lookup_widget(button,"valider_modif_malek");
gtk_widget_show(valider_modif_malek);

supprimerplantmalek= lookup_widget(button,"supprimerplantmalek");
gtk_widget_hide(supprimerplantmalek);
modifierplantmalek= lookup_widget(button,"modifierplantmalek");
gtk_widget_hide(modifierplantmalek);

treeview_cal=lookup_widget(button,"treeview_cal");
gtk_widget_hide(treeview_cal);

}


void
on_modifierplantmalek_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *modifpmalek;
GtkWidget *calendrier;

calendrier=lookup_widget(button,"calendrierpmalek");
modifpmalek= lookup_widget(button,"modifpmalek"); 
gtk_widget_destroy(calendrier);
modifpmalek=create_modifpmalek();
gtk_widget_show(modifpmalek);

}


void
on_supprimerplantmalek_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *supprimerpmalek;
GtkWidget *calendrier;

calendrier=lookup_widget(button,"calendrierpmalek");
supprimerpmalek= lookup_widget(button,"supprimerpmalek"); 
gtk_widget_destroy(calendrier);
supprimerpmalek=create_supprimerpmalek();
gtk_widget_show(supprimerpmalek);


}


void
on_precedentcaland_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *accueil;
GtkWidget *calendrier;

calendrier=lookup_widget(button,"calendrierpmalek");//calendrier pointe vers la fenetre calendrierpmalek
accueil= lookup_widget(button,"accueilmalek"); //accueil pointe vers la fenetre accueilmalek
gtk_widget_destroy(calendrier);
accueil=create_accueilmalek();
gtk_widget_show(accueil);

}


void
on_calpmalek_clicked                   (GtkButton       *button,
                                        gpointer         user_data)  	//ce bout de code ci dessous permet de se déplacer d'une fenetre à une autre, avec un peu de modification au niveau des variables on est libre de se deplacer librement entre les fentres désirées
{
GtkWidget *accueil;
GtkWidget *calendrier,*treeview,*ok_modif_m;
GtkWidget *valider_modif_malek,*nomplantemalek,*jourpmalek,*jourrmalek,*qtemalek,*moispmalek,*moisrmalek,*anneepmalek,*annermalek,*label1,*label2,*label3;

accueil= lookup_widget(button,"accueilmalek"); //accueil pointe vers la fenetre accueilmalek
gtk_widget_destroy(accueil);



calendrier=lookup_widget(button,"calendrierpmalek");//calendrier pointe vers la fenetre calendrierpmalek
calendrier=create_calendrierpmalek();
gtk_widget_show(calendrier);



nomplantemalek= lookup_widget(calendrier,"nomplantemalek");
gtk_widget_hide(nomplantemalek);

ok_modif_m= lookup_widget(calendrier,"ok_modif_m");
gtk_widget_hide(ok_modif_m);

jourpmalek= lookup_widget(calendrier,"jourpmalek");
gtk_widget_hide(jourpmalek);

jourrmalek= lookup_widget(calendrier,"jourrmalek");
gtk_widget_hide(jourrmalek);

moispmalek= lookup_widget(calendrier,"moispmalek");
gtk_widget_hide(moispmalek);

moisrmalek= lookup_widget(calendrier,"moisrmalek");
gtk_widget_hide(moisrmalek);

anneepmalek= lookup_widget(calendrier,"anneepmalek");
gtk_widget_hide(anneepmalek);

annermalek= lookup_widget(calendrier,"annermalek");
gtk_widget_hide(annermalek);

qtemalek= lookup_widget(calendrier,"qtemalek");
gtk_widget_hide(qtemalek);

label1= lookup_widget(calendrier,"label7");
gtk_widget_hide(label1);

label2= lookup_widget(calendrier,"label8");
gtk_widget_hide(label2);

label3= lookup_widget(calendrier,"label19");
gtk_widget_hide(label3);
valider_modif_malek= lookup_widget(calendrier,"valider_modif_malek");
gtk_widget_hide(valider_modif_malek);


treeview=lookup_widget(calendrier,"treeview_cal");
afficher_plante(treeview);

}


void
on_anneesmalek_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_pdispomalek_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{/*
GtkWidget *accueil;
GtkWidget *produitdispomalek;
GtkWidget *affichemalek;

accueil= lookup_widget(button,"accueilmalek");
gtk_widget_destroy(accueil);

produitdispomalek=lookup_widget(button,"produitdispomalek");
produitdispomalek=create_produitdispomalek();
gtk_widget_show(produitdispomalek);
affichemalek=lookup_widget(produitdispomalek,"affichemalek");
afficher_plante(affichemalek);
//anneeseche();*/
}


void
on_paccueil_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_modifpval_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *idmodifmalek,*nomplantemalek, *jourpmalek, *moispmalek, *anneepmalek, *jourrmalek, *moisrmalek, *annermalek, *qtemalek; 
GtkWidget *supprimerplantmalek;
GtkWidget *calendrier;
GtkWidget *modifierplantmalek, *modifpmalek, *entrytest;
GtkWidget *ajouterplantmalek,*valider_modif_malek, *treeview_cal ;
int id;
FILE *f;
plante h,p;
FILE *i;
int test;
i=fopen("/home/mohamed/Projets/farm/inter.txt","w+");
f=fopen("/home/mohamed/Projets/farm/plante.txt","r");
idmodifmalek= lookup_widget(button,"idmodifmalek"); 
id=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(idmodifmalek));
while(fscanf(f,"%d %s %d %s %d %d %s %d %d\n",&h.id,h.nom,&h.plantation.jour,h.plantation.mois,&h.plantation.annee,&h.recolte.jour,h.recolte.mois,&h.recolte.annee,&h.qte)!=EOF){
if( id==h.id)
fprintf(i,"%d %s %d %s %d %d %s %d %d\n",h.id,h.nom,h.plantation.jour,h.plantation.mois,h.plantation.annee,h.recolte.jour,h.recolte.mois,h.recolte.annee,h.qte);}
fclose(f);

calendrier=lookup_widget(button,"calendrierpmalek");
calendrier=create_calendrierpmalek();
ajouterplantmalek= lookup_widget(calendrier,"ajouterplantmalek");
supprimerplantmalek= lookup_widget(calendrier,"supprimerplantmalek");
modifierplantmalek= lookup_widget(calendrier,"modifierplantmalek");
valider_modif_malek=lookup_widget(calendrier,"valider_modif_malek");

gtk_widget_hide(ajouterplantmalek);
gtk_widget_hide(modifierplantmalek);
gtk_widget_hide(supprimerplantmalek);
gtk_widget_hide(valider_modif_malek);


nomplantemalek=lookup_widget(calendrier,"nomplantemalek");
jourpmalek=lookup_widget(calendrier,"jourpmalek");
moispmalek=lookup_widget(calendrier,"moispmalek");
anneepmalek=lookup_widget(calendrier,"anneepmalek");
jourrmalek=lookup_widget(calendrier,"jourrmalek");
moisrmalek=lookup_widget(calendrier,"moisrmalek");
annermalek=lookup_widget(calendrier,"annermalek");
qtemalek=lookup_widget(calendrier,"qtemalek");
modifpmalek= lookup_widget(button,"modifpmalek"); 
treeview_cal=lookup_widget(calendrier,"treeview_cal");
gtk_widget_hide(treeview_cal);
gtk_widget_destroy(modifpmalek);
gtk_widget_show(calendrier);



fclose(f);
fclose(i);
}


void
on_precmodifpmalek_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *modifpmalek;
GtkWidget *calendrier;


modifpmalek= lookup_widget(button,"modifpmalek"); //accueil pointe vers la fenetre accueilmalek
gtk_widget_destroy(modifpmalek);

calendrier=lookup_widget(button,"calendrierpmalek");//calendrier pointe vers la fenetre calendrierpmalek
calendrier=create_calendrierpmalek();
gtk_widget_show(calendrier);

}


void
on_precsuppmalek_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *supprimerpmalek;
GtkWidget *calendrier;

calendrier=lookup_widget(button,"calendrierpmalek");
supprimerpmalek= lookup_widget(button,"supprimerpmalek"); 
gtk_widget_destroy(supprimerpmalek);
calendrier=create_calendrierpmalek();
gtk_widget_show(calendrier);

}


void
on_validersuppmalek_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *supprimerpmalek;
GtkWidget *accueil;
GtkWidget *id_supp_malek;
int id;

id_supp_malek=lookup_widget(button,"id_supp_malek");
accueil=lookup_widget(button,"calendrierpmalek");
supprimerpmalek= lookup_widget(button,"supprimerpmalek"); 

id=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(id_supp_malek));
gtk_widget_destroy(supprimerpmalek);

accueil=create_accueilmalek();
gtk_widget_show(accueil);


supprimer_plante(id);
}


void
on_valider_modif_malek_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *nomplantmalek, *jourpmalek, *moispmalek, *anneepmalek, *jourrmalek, *moisrmalek, *annermalek, *qtemalek; //declaration des variables qui vont pointer vers les entrées : combobox spinbuttons
FILE *f; //f est un fichier
GtkWidget *accueil;
GtkWidget *calendrier;
plante p;

nomplantmalek=lookup_widget(button,"nomplantemalek"); // ces lignes sont pour l'affectation des ponteurs pour les input dans la fenetre
jourpmalek=lookup_widget(button,"jourpmalek");
moispmalek=lookup_widget(button,"moispmalek");
anneepmalek=lookup_widget(button,"anneepmalek");
jourrmalek=lookup_widget(button,"jourrmalek");
moisrmalek=lookup_widget(button,"moisrmalek");
annermalek=lookup_widget(button,"annermalek");
qtemalek=lookup_widget(button,"qtemalek");

strcpy(p.nom,gtk_combo_box_get_active_text(GTK_COMBO_BOX(nomplantmalek))); // pour lire le contenue du combobox
p.plantation.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jourpmalek));  	// pour lire le contenue du spinbutton
strcpy(p.plantation.mois,gtk_combo_box_get_active_text(GTK_COMBO_BOX(moispmalek)));
p.plantation.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(anneepmalek));
p.recolte.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jourrmalek));
strcpy(p.recolte.mois,gtk_combo_box_get_active_text(GTK_COMBO_BOX(moisrmalek)));
p.recolte.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annermalek));
p.qte=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(qtemalek));

ajouter_plante(p);


calendrier=lookup_widget(button,"calendrierpmalek");//calendrier pointe vers la fenetre calendrierpmalek
accueil= lookup_widget(button,"accueilmalek"); //accueil pointe vers la fenetre accueilmalek
gtk_widget_destroy(calendrier);
accueil=create_accueilmalek();
gtk_widget_show(accueil);
}


void
on_ok_modif_m_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *nomplantmalek, *jourpmalek, *moispmalek, *anneepmalek, *jourrmalek, *moisrmalek, *annermalek, *qtemalek; //declaration des variables qui vont pointer vers les entrées : combobox spinbuttons

GtkWidget *accueilmalek;
GtkWidget *calendrierpmalek;
plante p,h;
FILE *i;
i=fopen("/home/mohamed/Projets/farm/inter.txt","r");

fscanf(i,"%d %s %d %s %d %d %s %d %d\n",&h.id,h.nom,&h.plantation.jour,h.plantation.mois,&h.plantation.annee,&h.recolte.jour,h.recolte.mois,&h.recolte.annee,&h.qte);
fclose(i);

nomplantmalek=lookup_widget(button,"nomplantemalek"); // ces lignes sont pour l'affectation des ponteurs pour les input dans la fenetre
jourpmalek=lookup_widget(button,"jourpmalek");
moispmalek=lookup_widget(button,"moispmalek");
anneepmalek=lookup_widget(button,"anneepmalek");
jourrmalek=lookup_widget(button,"jourrmalek");
moisrmalek=lookup_widget(button,"moisrmalek");
annermalek=lookup_widget(button,"annermalek");
qtemalek=lookup_widget(button,"qtemalek");

strcpy(p.nom,gtk_combo_box_get_active_text(GTK_COMBO_BOX(nomplantmalek))); // pour lire le contenue du combobox
p.plantation.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jourpmalek));  	// pour lire le contenue du spinbutton
strcpy(p.plantation.mois,gtk_combo_box_get_active_text(GTK_COMBO_BOX(moispmalek)));
p.plantation.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(anneepmalek));
p.recolte.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jourrmalek));
strcpy(p.recolte.mois,gtk_combo_box_get_active_text(GTK_COMBO_BOX(moisrmalek)));
p.recolte.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annermalek));
p.qte=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(qtemalek));
supprimer_plante(h.id);
p.id=h.id;
ajouter_plante(p);
fclose(i);

accueilmalek= lookup_widget(button,"accueilmalek");
accueilmalek=create_accueilmalek();
gtk_widget_show(accueilmalek);

calendrierpmalek= lookup_widget(button,"calendrierpmalek");
gtk_widget_destroy(calendrierpmalek);

}


void
on_pas_acc_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *accueil;
GtkWidget *produitdispomalek;

produitdispomalek=lookup_widget(button,"produitdispomalek");
accueil= lookup_widget(button,"accueilmalek"); 
gtk_widget_destroy(produitdispomalek);
accueil=create_accueilmalek();
gtk_widget_show(accueil);
}

