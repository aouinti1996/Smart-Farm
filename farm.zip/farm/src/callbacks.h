#include <gtk/gtk.h>


void
on_ajouterpmalek_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_chercherpmalek_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_supprimerpmalek_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_ajouterplantmalek_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifierplantmalek_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_supprimerplantmalek_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_precedentcaland_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_calpmalek_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_anneesmalek_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_pdispomalek_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_paccueil_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifpval_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_precmodifpmalek_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_precsuppmalek_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_validersuppmalek_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_valider_modif_malek_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_ok_modif_m_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_pas_acc_clicked                     (GtkButton       *button,
                                        gpointer         user_data);
