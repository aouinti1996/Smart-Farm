#include <stdio.h>
#include <string.h>
#include "plante.h"
#include <gtk/gtk.h>
#include <stdlib.h>
#include <wctype.h>

enum{
ID,
NOM,
JOURP,
MOISP,
ANNEEP,
JOURR,
MOISR,
ANNEER,
QUANTITE,
COLUMNS};

void ajouter_plante(plante p)
{
plante h;
FILE *f;
int max=0;
f=fopen("/home/mohamed/Projets/farm/plante.txt","r");
while (fscanf(f,"%d %s %d %s %d %d %s %d %d\n",&h.id,h.nom,&h.plantation.jour,h.plantation.mois,&h.plantation.annee,&h.recolte.jour,h.recolte.mois,&h.recolte.annee,&h.qte)!=EOF)
{if (h.id>=max)
max=h.id;
}
fclose(f);
f=fopen("/home/mohamed/Projets/farm/plante.txt","a+");
if(f!=NULL)
fprintf(f,"%d %s %d %s %d %d %s %d %d\n",max+1,p.nom,p.plantation.jour,p.plantation.mois,p.plantation.annee,p.recolte.jour,p.recolte.mois,p.recolte.annee,p.qte);
fclose(f);
}


void supprimer_plante(int id){

FILE *f;
FILE *H;
plante h ;

f=fopen("/home/mohamed/Projets/farm/plante.txt","r");
H=fopen("/home/mohamed/Projets/farm/inter.txt","w+");
while(fscanf(f,"%d %s %d %s %d %d %s %d %d\n",&h.id,h.nom,&h.plantation.jour,h.plantation.mois,&h.plantation.annee,&h.recolte.jour,h.recolte.mois,&h.recolte.annee,&h.qte)!=EOF){
if( id!=h.id)
fprintf(H,"%d %s %d %s %d %d %s %d %d\n",h.id,h.nom,h.plantation.jour,h.plantation.mois,h.plantation.annee,h.recolte.jour,h.recolte.mois,h.recolte.annee,h.qte);
}
fclose(f);
fclose(H);
remove("/home/mohamed/Projets/farm/plante.txt");
rename("/home/mohamed/Projets/farm/inter.txt","/home/mohamed/Projets/farm/plante.txt");
}


void modifier_plante(int a)
{FILE *f;
plante h;

f=fopen("/home/mohamed/Projets/farm/plante.txt","a+");
while(fscanf(f,"%d %s %d %s %d %d %s %d %d\n",&h.id,h.nom,&h.plantation.jour,h.plantation.mois,&h.plantation.annee,&h.recolte.jour,h.recolte.mois,&h.recolte.annee,&h.qte)!=EOF)
if(h.id==a)
{supprimer_plante(a);}
fclose(f);
}


void afficher_plante(GtkWidget *treeview)
{

GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char nom[20],moisp[20],moisr[20];
int id,qte,jourp,jourr,anneep,anneer;



store=NULL;
FILE *f;
store=gtk_tree_view_get_model(treeview);

if (store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("id",renderer, "text",ID, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nom",renderer, "text",NOM, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("jourp", renderer, "text",JOURP, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("moisp", renderer, "text",MOISP, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("anneep", renderer, "text",ANNEEP, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("jourr", renderer, "text",JOURR, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("moisr", renderer, "text",MOISR, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("anneer", renderer, "text",ANNEER, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("qte", renderer, "text",QUANTITE, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);


store=gtk_list_store_new(COLUMNS, G_TYPE_INT,  G_TYPE_STRING, G_TYPE_INT,  G_TYPE_STRING, G_TYPE_INT, G_TYPE_INT,  G_TYPE_STRING, G_TYPE_INT, G_TYPE_INT);


f=fopen("/home/mohamed/Projets/farm/plante.txt","a+");
if(f ==NULL)
	{

		return;
	}		
	if(f!=NULL)
	{

while (fscanf(f,"%d %s %d %s %d %d %s %d %d\n",&id,nom,&jourp,moisp,&anneep,&jourr,moisr,&anneer,&qte)!=EOF)
{
gtk_list_store_append(store, &iter);
gtk_list_store_set (store, &iter,ID,id,NOM,nom,JOURP,jourp,MOISP,moisp,ANNEEP,anneep,JOURR,jourr,MOISR,moisr,ANNEER,anneer,QUANTITE,qte, -1);

}
fclose(f);}
gtk_tree_view_set_model(GTK_TREE_VIEW(treeview), GTK_TREE_MODEL(store));
g_object_unref(store);
}
}

/*
void anneeseche()

{int aux=0,i,j=0;
int T[10];
plante h;
FILE *f,*as,*test;
test=fopen("/home/mohamed/Projets/farm/tas.txt","w+");
as=fopen("/home/mohamed/Projets/farm/as.txt","w+");
f=fopen("/home/mohamed/Projets/farm/plante.txt","r");
while (fscanf(f,"%d %s %d %s %d %d %s %d %d\n",&h.id,h.nom,&h.plantation.jour,h.plantation.mois,&h.plantation.annee,&h.recolte.jour,h.recolte.mois,&h.recolte.annee,&h.qte)!=EOF)
{
fprintf(as,"%d %d\n",h.recolte.annee,h.qte);
}

while (fscanf(as,"%d %d\n",&h.recolte.annee,&h.qte)!=EOF)
{
if((h.recolte.annee)==2020)
aux=aux+(h.qte);

}
T[0]=aux;

fprintf(test,"%d\n",T[0]);
fclose(f);fclose(as);fclose(test);

}*/

