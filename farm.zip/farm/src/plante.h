#include <gtk/gtk.h>

typedef struct{
int jour;
char mois[20];
int annee;
}DATE;

typedef struct{
int id;
char nom[20];
DATE plantation;
DATE recolte;
int qte;
}plante;


void ajouter_plante(plante h);
void supprimer_plante(int id);
void afficher_plante(GtkWidget *treeview);
void modifier_plante(int a);
void rechercher_plante(GtkWidget *liste,char ch[30]);
//void anneeseche();
